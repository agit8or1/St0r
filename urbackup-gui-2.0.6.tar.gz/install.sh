#!/bin/bash

set -e

# Version of this installer
INSTALLER_VERSION="2.0.6"
INSTALLER_DATE="2025-11-11"

echo "============================================"
echo "St0r (UrBackup GUI) Installation/Upgrade Script"
echo "Version: $INSTALLER_VERSION ($INSTALLER_DATE)"
echo "============================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
   echo "Please run as root (use sudo)"
   exit 1
fi

# Get the actual user who ran sudo
ACTUAL_USER="${SUDO_USER:-$USER}"
INSTALL_DIR="/opt/urbackup-gui"
VERSION_FILE="$INSTALL_DIR/.version"

# Check if already installed
EXISTING_INSTALL=false
CURRENT_VERSION="unknown"
CURRENT_DATE="unknown"

if [ -d "$INSTALL_DIR" ] && [ -f "/etc/systemd/system/urbackup-gui.service" ]; then
    EXISTING_INSTALL=true

    # Read current version if available
    if [ -f "$VERSION_FILE" ]; then
        CURRENT_VERSION=$(grep "VERSION=" "$VERSION_FILE" | cut -d= -f2)
        CURRENT_DATE=$(grep "DATE=" "$VERSION_FILE" | cut -d= -f2)
    fi

    echo "✓ Existing installation detected"
    echo ""
    echo "Current version: $CURRENT_VERSION (installed: $CURRENT_DATE)"
    echo "New version:     $INSTALLER_VERSION (released: $INSTALLER_DATE)"
    echo ""

    # Compare versions
    if [ "$CURRENT_VERSION" = "$INSTALLER_VERSION" ]; then
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo "You already have the latest version installed!"
        echo "━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━"
        echo ""
        echo "Options:"
        echo "  • To repair/reinstall: Type 'y' below"
        echo "  • To keep current installation: Type 'n' or press Enter"
        echo ""
        read -p "Reinstall anyway (repair mode)? (y/N) " -n 1 -r < /dev/tty
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo ""
            echo "Installation cancelled - keeping current version."
            echo ""
            echo "If you're experiencing issues, try:"
            echo "  • sudo systemctl restart urbackup-gui"
            echo "  • sudo journalctl -u urbackup-gui -f  (to view logs)"
            exit 0
        fi
        echo ""
        echo "Starting reinstall (repair mode)..."
    else
        echo "An upgrade is available!"
        echo ""
        echo "What will happen:"
        echo "  ✓ Your data and settings will be preserved"
        echo "  ✓ Database will be backed up to /tmp"
        echo "  ✓ Application files will be updated"
        echo "  ✓ Services will be restarted"
        echo ""
        read -p "Continue with upgrade? (y/N) " -n 1 -r < /dev/tty
        echo ""
        if [[ ! $REPLY =~ ^[Yy]$ ]]; then
            echo ""
            echo "Upgrade cancelled by user."
            echo ""
            echo "Your current installation ($CURRENT_VERSION) will remain unchanged."
            echo "Run this script again anytime to upgrade to version $INSTALLER_VERSION."
            exit 0
        fi
        echo ""
        echo "Starting upgrade process..."
    fi
else
    echo "No existing installation found."
    echo "Starting fresh installation of version $INSTALLER_VERSION..."
fi

echo ""
echo "Installing as user: $ACTUAL_USER"
echo "Installation directory: $INSTALL_DIR"
echo ""

# Update system
echo "[1/9] Updating system packages..."
apt-get update

# Install dependencies
echo "[2/9] Installing system dependencies..."
apt-get install -y curl gnupg2 software-properties-common nginx mariadb-server

# Install Node.js 20
echo "[3/9] Installing Node.js 20..."
if ! command -v node &> /dev/null; then
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
fi

echo "Node.js version: $(node --version)"
echo "npm version: $(npm --version)"

# Stop services if upgrading
if [ "$EXISTING_INSTALL" = true ]; then
    echo "[4/9] Stopping services for upgrade..."
    systemctl stop urbackup-gui || true

    # Backup existing .env file
    if [ -f "$INSTALL_DIR/backend/.env" ]; then
        cp "$INSTALL_DIR/backend/.env" "/tmp/urbackup-gui.env.backup"
        echo "  ✓ Backed up .env file"
    fi

    # Backup database before upgrade
    echo "  Creating database backup..."
    mysqldump -u root urbackup_gui > "/tmp/urbackup_gui_backup_$(date +%Y%m%d_%H%M%S).sql" 2>/dev/null || echo "  Warning: Could not backup database"
else
    echo "[4/9] Creating installation directory..."
fi

# Copy/update application files
mkdir -p $INSTALL_DIR

# Determine installation method
SCRIPT_DIR="$( cd "$( dirname "${BASH_SOURCE[0]}" )" && pwd )"
DOWNLOAD_URL="https://stor.agit8or.net/downloads/urbackup-gui.tar.gz"
IS_SOURCE_INSTALL=false

# Check if we're running from a source directory (local install) or need to download
if [ -d "$SCRIPT_DIR/backend" ] && [ -d "$SCRIPT_DIR/frontend" ]; then
    # Local installation from source directory
    echo "  Using local source files from: $SCRIPT_DIR"
    cp -r $SCRIPT_DIR/* $INSTALL_DIR/
    chown -R $ACTUAL_USER:$ACTUAL_USER $INSTALL_DIR

    # Check if this is a source install (has src/ directories)
    if [ -d "$INSTALL_DIR/backend/src" ]; then
        IS_SOURCE_INSTALL=true
    fi
else
    # Remote installation - download package
    echo "  Downloading latest package from: $DOWNLOAD_URL"
    TEMP_PACKAGE="/tmp/urbackup-gui-download-$$.tar.gz"

    if ! curl -fSL "$DOWNLOAD_URL" -o "$TEMP_PACKAGE"; then
        echo ""
        echo "ERROR: Failed to download package from $DOWNLOAD_URL"
        echo ""
        echo "Alternative installation method:"
        echo "  1. Download source: git clone <repository-url>"
        echo "  2. cd urbackup-gui"
        echo "  3. sudo ./install.sh"
        exit 1
    fi

    # Extract package
    echo "  Extracting package..."
    cd /tmp
    tar -xzf "$TEMP_PACKAGE"

    if [ ! -d "/tmp/urbackup-gui" ]; then
        echo "ERROR: Package extraction failed or invalid package structure"
        rm -f "$TEMP_PACKAGE"
        exit 1
    fi

    # Copy files to installation directory
    cp -r /tmp/urbackup-gui/* $INSTALL_DIR/
    chown -R $ACTUAL_USER:$ACTUAL_USER $INSTALL_DIR

    # Cleanup
    rm -rf /tmp/urbackup-gui "$TEMP_PACKAGE"
    echo "  ✓ Package downloaded and extracted (pre-built)"
fi

# Restore .env file if it was backed up
if [ -f "/tmp/urbackup-gui.env.backup" ]; then
    cp "/tmp/urbackup-gui.env.backup" "$INSTALL_DIR/backend/.env"
    rm "/tmp/urbackup-gui.env.backup"
    echo "  ✓ Restored .env configuration"
fi

# Configure MariaDB
echo "[5/9] Configuring MariaDB..."
systemctl start mariadb
systemctl enable mariadb

# Create database and user (only if fresh install)
if [ "$EXISTING_INSTALL" = false ]; then
    mysql -u root <<EOF
CREATE DATABASE IF NOT EXISTS urbackup_gui;
CREATE USER IF NOT EXISTS 'urbackup'@'localhost' IDENTIFIED BY 'urbackup123';
GRANT ALL PRIVILEGES ON urbackup_gui.* TO 'urbackup'@'localhost';
FLUSH PRIVILEGES;
EOF

    # Run database schema
    echo "[6/9] Setting up database schema..."
    mysql -u root urbackup_gui < $INSTALL_DIR/database/init/01_schema.sql
else
    echo "[6/9] Skipping database initialization (upgrade mode)..."
    # In upgrade mode, you might want to run migrations here
    # mysql -u root urbackup_gui < $INSTALL_DIR/database/migrations/*.sql
fi

# Install backend dependencies
echo "[7/9] Installing backend dependencies..."
cd $INSTALL_DIR/backend
# Remove node_modules to ensure clean install
rm -rf node_modules
sudo -u $ACTUAL_USER npm install --omit=dev

if [ "$IS_SOURCE_INSTALL" = true ]; then
    echo "  Building backend from source..."
    sudo -u $ACTUAL_USER npm run build
else
    echo "  ✓ Using pre-built backend files"
fi

# Install and build frontend
if [ "$IS_SOURCE_INSTALL" = true ]; then
    echo "[8/9] Building frontend from source..."
    cd $INSTALL_DIR/frontend
    rm -rf node_modules
    sudo -u $ACTUAL_USER npm install
    sudo -u $ACTUAL_USER npm run build
else
    echo "[8/9] Frontend setup..."
    echo "  ✓ Using pre-built frontend files (no build required)"
fi

# Configure nginx
echo "[9/9] Configuring nginx..."
cp $INSTALL_DIR/setup/nginx-site.conf /etc/nginx/sites-available/urbackup-gui
ln -sf /etc/nginx/sites-available/urbackup-gui /etc/nginx/sites-enabled/urbackup-gui
rm -f /etc/nginx/sites-enabled/default

# Create systemd service for backend
cp $INSTALL_DIR/setup/urbackup-gui.service /etc/systemd/system/
systemctl daemon-reload

# Create .env file if it doesn't exist
if [ ! -f "$INSTALL_DIR/backend/.env" ]; then
    cat > $INSTALL_DIR/backend/.env <<EOF
NODE_ENV=production
PORT=3000
DB_HOST=localhost
DB_PORT=3306
DB_NAME=urbackup_gui
DB_USER=urbackup
DB_PASSWORD=urbackup123
JWT_SECRET=$(openssl rand -hex 32)
EOF
    chown $ACTUAL_USER:$ACTUAL_USER $INSTALL_DIR/backend/.env
fi

# Start services
echo ""
echo "Starting services..."
systemctl restart urbackup-gui
systemctl enable urbackup-gui
systemctl restart nginx
systemctl enable nginx

# Write version file
echo "VERSION=$INSTALLER_VERSION" > "$VERSION_FILE"
echo "DATE=$INSTALLER_DATE" >> "$VERSION_FILE"
chown $ACTUAL_USER:$ACTUAL_USER "$VERSION_FILE"

echo ""
if [ "$EXISTING_INSTALL" = true ]; then
    echo "============================================"
    echo "Upgrade Complete!"
    echo "============================================"
    echo ""
    echo "St0r has been successfully upgraded to version $INSTALLER_VERSION."
    echo ""
    echo "Database backups are stored in: /tmp/urbackup_gui_backup_*.sql"
else
    echo "============================================"
    echo "Installation Complete!"
    echo "============================================"
    echo ""
    echo "St0r (UrBackup GUI) version $INSTALLER_VERSION is now running at:"
    echo "  http://$(hostname -I | awk '{print $1}')"
    echo ""
    echo "Default credentials:"
    echo "  Username: admin"
    echo "  Password: admin123"
    echo ""
    echo "IMPORTANT: Change the default password immediately!"
fi

echo ""
echo "Useful commands:"
echo "  sudo systemctl status urbackup-gui  - Check backend status"
echo "  sudo systemctl restart urbackup-gui - Restart backend"
echo "  sudo systemctl status nginx         - Check nginx status"
echo "  sudo journalctl -u urbackup-gui -f  - View backend logs"
echo ""
