import { Request, Response } from 'express';
import { getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';
import mysql from 'mysql2/promise';

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'urbackup_gui'
};

const DEFAULTS: Record<string, any> = {
  // Interval settings (UrBackup format: "4h", "168h")
  update_freq_incr: '4h',
  update_freq_full: '168h',
  update_freq_image_incr: '24h',
  update_freq_image_full: '720h',

  // Backup windows (empty = always)
  backup_window_incr_file: '',
  backup_window_full_file: '',
  backup_window_incr_image: '',
  backup_window_full_image: '',

  // Min/Max counts
  max_file_incr: 100,
  max_file_full: 10,
  min_file_incr: 2,
  min_file_full: 2,
  max_image_incr: 30,
  max_image_full: 5,
  min_image_incr: 2,
  min_image_full: 2,

  // Other settings
  startup_backup_delay: 0,
  max_active_clients: 100,
  global_soft_fs_quota: '95%',
  internet_mode_enabled: false,
  no_images: false,
  autoshutdown: false,
  allow_overwrite: false,
  silent_update: false
};

function isCorrupted(value: any): boolean {
  if (value === null || value === undefined) return false;
  const str = String(value);
  return str === 'NaN' ||
         str === 'undefined' ||
         str === '[object Object]' ||
         str === 'null' ||
         (typeof value === 'number' && isNaN(value));
}

function getDefaultValue(key: string): any {
  return DEFAULTS[key] || '';
}

// Import settings from UrBackup to database
export async function importSettings(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can import settings' });
      return;
    }

    logger.info(`Settings import initiated by user: ${user.username}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const service = new UrBackupService(server);
    const settings = await service.getSettings();

    logger.info(`Fetched ${Object.keys(settings).length} settings from UrBackup`);

    let imported = 0;
    let corrupted = 0;

    for (const [key, value] of Object.entries(settings)) {
      const isCorruptedValue = isCorrupted(value);
      if (isCorruptedValue) {
        corrupted++;
        logger.warn(`Corrupted setting found: ${key} = ${value}`);
      }

      const valueType = typeof value;
      const valueStr = value === null || value === undefined ? null : String(value);

      await connection.execute(
        `INSERT INTO urbackup_settings_cache (server_id, setting_key, setting_value, value_type, is_corrupted)
         VALUES (?, ?, ?, ?, ?)
         ON DUPLICATE KEY UPDATE
         setting_value = VALUES(setting_value),
         value_type = VALUES(value_type),
         is_corrupted = VALUES(is_corrupted),
         last_synced = CURRENT_TIMESTAMP`,
        [server.id, key, valueStr, valueType, isCorruptedValue ? 1 : 0]
      );
      imported++;
    }

    logger.info(`Imported ${imported} settings, found ${corrupted} corrupted`);

    res.json({
      success: true,
      imported,
      corrupted,
      message: `Imported ${imported} settings from UrBackup (${corrupted} corrupted)`
    });

  } catch (error: any) {
    logger.error('Failed to import settings:', error);
    res.status(500).json({
      error: 'Failed to import settings',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// Clean corrupted settings in database
export async function cleanupDatabase(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can cleanup settings' });
      return;
    }

    logger.info(`Database cleanup initiated by user: ${user.username}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Get all corrupted settings
    const [corrupted]: any = await connection.execute(
      'SELECT setting_key, setting_value FROM urbackup_settings_cache WHERE server_id = ? AND is_corrupted = 1',
      [server.id]
    );

    logger.info(`Found ${corrupted.length} corrupted settings in database`);

    const fixed: Array<{key: string, oldValue: any, newValue: any}> = [];

    for (const row of corrupted) {
      const key = row.setting_key;
      const oldValue = row.setting_value;
      const newValue = getDefaultValue(key);

      logger.info(`Fixing ${key}: "${oldValue}" → "${newValue}"`);

      await connection.execute(
        'UPDATE urbackup_settings_cache SET setting_value = ?, value_type = ?, is_corrupted = 0 WHERE server_id = ? AND setting_key = ?',
        [String(newValue), typeof newValue, server.id, key]
      );

      fixed.push({ key, oldValue, newValue });
    }

    logger.info(`Fixed ${fixed.length} corrupted settings in database`);

    res.json({
      success: true,
      fixed: fixed.length,
      details: fixed
    });

  } catch (error: any) {
    logger.error('Failed to cleanup database:', error);
    res.status(500).json({
      error: 'Failed to cleanup database',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// Sync cleaned settings from database back to UrBackup
export async function syncToUrBackup(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can sync settings' });
      return;
    }

    logger.info(`Settings sync to UrBackup initiated by user: ${user.username}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Get all settings from database
    const [rows]: any = await connection.execute(
      'SELECT setting_key, setting_value, value_type FROM urbackup_settings_cache WHERE server_id = ?',
      [server.id]
    );

    logger.info(`Got ${rows.length} settings from database to sync`);

    // Convert to object
    const settingsToSync: any = {};
    for (const row of rows) {
      const key = row.setting_key;
      let value = row.setting_value;

      // Convert back to proper type
      if (row.value_type === 'boolean') {
        value = value === 'true' || value === '1' || value === 'True';
      } else if (row.value_type === 'number') {
        value = parseFloat(value);
      }

      settingsToSync[key] = value;
    }

    // Use the bulkSetSettings method which does direct HTTP to UrBackup
    const service = new UrBackupService(server);
    const result = await service.bulkSetSettings(settingsToSync);

    logger.info(`Sync result:`, result);

    if (result.success) {
      // Update last_synced for all settings
      await connection.execute(
        'UPDATE urbackup_settings_cache SET last_synced = CURRENT_TIMESTAMP WHERE server_id = ?',
        [server.id]
      );
    }

    res.json({
      success: result.success,
      synced: result.success ? rows.length : 0,
      failed: result.errors?.length || 0,
      details: result
    });

  } catch (error: any) {
    logger.error('Failed to sync settings:', error);
    res.status(500).json({
      error: 'Failed to sync settings',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// One-step: Import, Clean, and Sync
export async function fullCleanupAndSync(req: Request, res: Response) {
  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can perform full cleanup' });
      return;
    }

    logger.info(`Full cleanup and sync initiated by user: ${user.username}`);

    // Step 1: Import settings
    logger.info('Step 1/3: Importing settings from UrBackup...');
    const importReq = { ...req } as Request;
    const importRes = {
      json: (data: any) => data,
      status: (code: number) => importRes
    } as any;

    await importSettings(importReq, importRes);

    // Step 2: Clean database
    logger.info('Step 2/3: Cleaning corrupted settings...');
    const cleanReq = { ...req } as Request;
    const cleanRes = {
      json: (data: any) => data,
      status: (code: number) => cleanRes
    } as any;

    await cleanupDatabase(cleanReq, cleanRes);

    // Step 3: Sync back to UrBackup
    logger.info('Step 3/3: Syncing cleaned settings to UrBackup...');
    const syncReq = { ...req } as Request;
    const syncRes = {
      json: (data: any) => {
        res.json({
          success: true,
          message: 'Full cleanup and sync completed successfully',
          steps: {
            import: 'completed',
            cleanup: 'completed',
            sync: data
          }
        });
      },
      status: (code: number) => syncRes
    } as any;

    await syncToUrBackup(syncReq, syncRes);

  } catch (error: any) {
    logger.error('Failed full cleanup and sync:', error);
    res.status(500).json({
      error: 'Failed full cleanup and sync',
      message: error.message
    });
  }
}
