import { Request, Response } from 'express';
import { getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';
import mysql from 'mysql2/promise';

const dbConfig = {
  host: process.env.DB_HOST || 'localhost',
  user: process.env.DB_USER || 'root',
  password: process.env.DB_PASSWORD || '',
  database: process.env.DB_NAME || 'urbackup_gui'
};

interface ServerBackup {
  id: number;
  server_id: number;
  backup_name: string;
  settings_json: string;
  created_at: Date;
  created_by: string;
}

// Create backup of current UrBackup server settings
export async function createBackup(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can create backups' });
      return;
    }

    const { backupName } = req.body;
    const name = backupName || `Backup ${new Date().toISOString()}`;

    logger.info(`Creating server config backup: ${name}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const service = new UrBackupService(server);
    const settings = await service.getSettings();

    logger.info(`Fetched ${Object.keys(settings).length} settings from UrBackup`);

    // Store backup
    const [result]: any = await connection.execute(
      `INSERT INTO urbackup_server_backups (server_id, backup_name, settings_json, created_by)
       VALUES (?, ?, ?, ?)`,
      [server.id, name, JSON.stringify(settings), user.username]
    );

    logger.info(`Backup created with ID: ${result.insertId}`);

    res.json({
      success: true,
      backupId: result.insertId,
      backupName: name,
      settingsCount: Object.keys(settings).length,
      message: 'Server configuration backup created successfully'
    });

  } catch (error: any) {
    logger.error('Failed to create backup:', error);
    res.status(500).json({
      error: 'Failed to create backup',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// List all backups
export async function listBackups(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can view backups' });
      return;
    }

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const [backups]: any = await connection.execute(
      `SELECT id, backup_name, created_at, created_by
       FROM urbackup_server_backups
       WHERE server_id = ?
       ORDER BY created_at DESC`,
      [server.id]
    );

    res.json({
      success: true,
      backups: backups.map((b: any) => ({
        id: b.id,
        name: b.backup_name,
        createdAt: b.created_at,
        createdBy: b.created_by
      }))
    });

  } catch (error: any) {
    logger.error('Failed to list backups:', error);
    res.status(500).json({
      error: 'Failed to list backups',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// Restore from backup
export async function restoreBackup(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can restore backups' });
      return;
    }

    const { backupId } = req.params;

    logger.info(`Restoring from backup ID: ${backupId}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Get backup
    const [backups]: any = await connection.execute(
      'SELECT settings_json, backup_name FROM urbackup_server_backups WHERE id = ? AND server_id = ?',
      [backupId, server.id]
    );

    if (backups.length === 0) {
      res.status(404).json({ error: 'Backup not found' });
      return;
    }

    const settings = JSON.parse(backups[0].settings_json);
    const backupName = backups[0].backup_name;

    logger.info(`Restoring ${Object.keys(settings).length} settings from backup: ${backupName}`);

    // Use the bulkSetSettings method
    const service = new UrBackupService(server);
    const result = await service.bulkSetSettings(settings);

    logger.info('Restore result:', result);

    res.json({
      success: result.success,
      backupName,
      restored: Object.keys(settings).length,
      message: result.success
        ? 'Server configuration restored successfully'
        : 'Restore completed with some errors',
      details: result
    });

  } catch (error: any) {
    logger.error('Failed to restore backup:', error);
    res.status(500).json({
      error: 'Failed to restore backup',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// Delete backup
export async function deleteBackup(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can delete backups' });
      return;
    }

    const { backupId } = req.params;

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    await connection.execute(
      'DELETE FROM urbackup_server_backups WHERE id = ? AND server_id = ?',
      [backupId, server.id]
    );

    res.json({
      success: true,
      message: 'Backup deleted successfully'
    });

  } catch (error: any) {
    logger.error('Failed to delete backup:', error);
    res.status(500).json({
      error: 'Failed to delete backup',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}

// Get backup details
export async function getBackupDetails(req: Request, res: Response) {
  const connection = await mysql.createConnection(dbConfig);

  try {
    const user = (req as any).user;
    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can view backup details' });
      return;
    }

    const { backupId } = req.params;

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const [backups]: any = await connection.execute(
      'SELECT * FROM urbackup_server_backups WHERE id = ? AND server_id = ?',
      [backupId, server.id]
    );

    if (backups.length === 0) {
      res.status(404).json({ error: 'Backup not found' });
      return;
    }

    const backup = backups[0];
    const settings = JSON.parse(backup.settings_json);

    res.json({
      success: true,
      backup: {
        id: backup.id,
        name: backup.backup_name,
        createdAt: backup.created_at,
        createdBy: backup.created_by,
        settingsCount: Object.keys(settings).length,
        settings
      }
    });

  } catch (error: any) {
    logger.error('Failed to get backup details:', error);
    res.status(500).json({
      error: 'Failed to get backup details',
      message: error.message
    });
  } finally {
    await connection.end();
  }
}
