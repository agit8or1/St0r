import { Request, Response } from 'express';
import { getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';

const DEFAULTS: Record<string, any> = {
  // Interval settings (UrBackup format: number + unit)
  update_freq_incr: '4h',
  update_freq_full: '168h',
  update_freq_image_incr: '24h',
  update_freq_image_full: '720h',

  // Backup windows (empty = always)
  backup_window_incr_file: '',
  backup_window_full_file: '',
  backup_window_incr_image: '',
  backup_window_full_image: '',

  // Min/Max counts
  max_file_incr: 100,
  max_file_full: 10,
  min_file_incr: 2,
  min_file_full: 2,
  max_image_incr: 30,
  max_image_full: 5,
  min_image_incr: 2,
  min_image_full: 2,

  // Other settings
  startup_backup_delay: 0,
  max_active_clients: 100,
  global_soft_fs_quota: '95%',
  internet_mode_enabled: false,
  no_images: false,
  autoshutdown: false,
  allow_overwrite: false,
  silent_update: false
};

function isCorrupted(value: any): boolean {
  if (value === null || value === undefined) return false;

  const str = String(value);
  return str === 'NaN' ||
         str === 'undefined' ||
         str === '[object Object]' ||
         str === 'null' ||
         (typeof value === 'number' && isNaN(value));
}

function getDefaultValue(key: string, originalValue: any): any {
  if (key in DEFAULTS) {
    return DEFAULTS[key];
  }

  // Infer safe defaults
  if (typeof originalValue === 'boolean') return false;
  if (typeof originalValue === 'number') return 0;
  if (typeof originalValue === 'object') return '';

  return '';
}

export async function cleanupCorruptedSettings(req: Request, res: Response) {
  try {
    const user = (req as any).user;

    if (!user.isAdmin) {
      res.status(403).json({ error: 'Only administrators can cleanup settings' });
      return;
    }

    logger.info(`Settings cleanup initiated by user: ${user.username}`);

    const server = await getDefaultServer();
    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const service = new UrBackupService(server);
    const settings = await service.getSettings();

    const corrupted: Array<{ key: string; value: string }> = [];
    const fixed: Array<{ key: string; oldValue: string; newValue: any }> = [];
    const failed: Array<{ key: string; error: string }> = [];

    // Find corrupted settings and build corrected settings object
    const correctedSettings: Record<string, any> = {};

    for (const [key, value] of Object.entries(settings)) {
      if (isCorrupted(value)) {
        corrupted.push({ key, value: String(value) });
        const defaultValue = getDefaultValue(key, value);
        correctedSettings[key] = defaultValue;
        logger.info(`Will fix ${key}: ${value} → ${JSON.stringify(defaultValue)}`);
      }
    }

    logger.info(`Found ${corrupted.length} corrupted settings`);

    if (corrupted.length === 0) {
      logger.info('No corrupted settings found');
      res.json({
        success: true,
        summary: { corrupted: 0, fixed: 0, failed: 0 },
        details: { corrupted: [], fixed: [], failed: [] }
      });
      return;
    }

    // Save ALL corrected settings at once using bulk update
    try {
      logger.info('Saving all corrected settings using bulk update...');
      const result: any = await service.bulkSetSettings(correctedSettings);

      if (result.success) {
        // All succeeded
        for (const { key, value } of corrupted) {
          fixed.push({ key, oldValue: value, newValue: correctedSettings[key] });
        }
        logger.info(`Successfully fixed all ${fixed.length} corrupted settings`);
      } else {
        // Some or all failed
        logger.error('Failed to save corrected settings:', result.errors);
        for (const { key, value } of corrupted) {
          const error = result.errors?.find((e: any) => e.key === key);
          if (error) {
            failed.push({ key, error: error.error });
          } else {
            fixed.push({ key, oldValue: value, newValue: correctedSettings[key] });
          }
        }
      }
    } catch (error: any) {
      logger.error('Failed to save corrected settings:', error);
      for (const { key } of corrupted) {
        failed.push({ key, error: error.message });
      }
    }

    logger.info(`Cleanup complete. Fixed: ${fixed.length}, Failed: ${failed.length}`);

    res.json({
      success: true,
      summary: {
        corrupted: corrupted.length,
        fixed: fixed.length,
        failed: failed.length
      },
      details: {
        corrupted,
        fixed,
        failed
      }
    });
  } catch (error: any) {
    logger.error('Failed to cleanup settings:', error);
    res.status(500).json({
      error: 'Failed to cleanup settings',
      message: error.message
    });
  }
}
