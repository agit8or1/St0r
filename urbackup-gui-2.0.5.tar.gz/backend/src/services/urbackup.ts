import { UrbackupServer } from 'urbackup-server-api';
import { UrBackupServer } from '../models/server.js';
import { logger } from '../utils/logger.js';

export class UrBackupService {
  private api: UrbackupServer;
  private serverConfig: UrBackupServer;

  constructor(serverConfig: UrBackupServer) {
    this.serverConfig = serverConfig;
    const url = `http://${serverConfig.host}:${serverConfig.port}`;
    this.api = new UrbackupServer({
      url,
      username: serverConfig.username,
      password: serverConfig.password,
    });
  }

  async testConnection(): Promise<boolean> {
    try {
      await this.api.getStatus();
      return true;
    } catch (error) {
      logger.error('UrBackup connection test failed:', error);
      return false;
    }
  }

  async getStatus() {
    try {
      return await this.api.getStatus();
    } catch (error) {
      logger.error('Failed to get status:', error);
      throw error;
    }
  }

  async getClients() {
    try {
      return await this.api.getClients();
    } catch (error) {
      logger.error('Failed to get clients:', error);
      throw error;
    }
  }

  async getOnlineClients() {
    try {
      return await this.api.getOnlineClients();
    } catch (error) {
      logger.error('Failed to get online clients:', error);
      throw error;
    }
  }

  async getOfflineClients() {
    try {
      return await this.api.getOfflineClients();
    } catch (error) {
      logger.error('Failed to get offline clients:', error);
      throw error;
    }
  }

  async getFailedClients() {
    try {
      return await this.api.getFailedClients();
    } catch (error) {
      logger.error('Failed to get failed clients:', error);
      throw error;
    }
  }

  async getOkClients() {
    try {
      return await this.api.getOkClients();
    } catch (error) {
      logger.error('Failed to get OK clients:', error);
      throw error;
    }
  }

  async getActivities() {
    try {
      const activities = await this.api.getActivities();

      // Log the raw structure to help debug
      if (activities && typeof activities === 'object') {
        const data = activities as any;
        if (data.last && data.last.length > 0) {
          logger.info('=== ACTIVITY DEBUGGING ===');
          logger.info(`Total last activities: ${data.last.length}`);

          // Find dewey-work specifically (case insensitive)
          const deweyActivity = data.last.find((a: any) => {
            const name = (a.name || '').toLowerCase();
            const client = (a.client || '').toLowerCase();
            return name.includes('dewey') || client.includes('dewey');
          });

          if (deweyActivity) {
            logger.info('DEWEY ACTIVITY FOUND:');
            logger.info(JSON.stringify(deweyActivity, null, 2));
          }

          // Log first few activities with full JSON
          logger.info('First 3 activities:');
          data.last.slice(0, 3).forEach((activity: any, index: number) => {
            logger.info(`Activity ${index + 1}: ${JSON.stringify(activity, null, 2)}`);
          });
        }
      }

      return activities;
    } catch (error) {
      logger.error('Failed to get activities:', error);
      throw error;
    }
  }

  async getCurrentActivities() {
    try {
      return await this.api.getCurrentActivities();
    } catch (error) {
      logger.error('Failed to get current activities:', error);
      throw error;
    }
  }

  async getBackups(clientId: string) {
    try {
      // Convert string ID to number and pass as clientId parameter
      const numericId = parseInt(clientId);
      logger.info(`Getting backups for client ID: ${numericId}`);

      const backups = await this.api.getBackups({ clientId: numericId });

      logger.info(`Full backups response: ${JSON.stringify(backups)}`);

      logger.info(`Backups response structure:`, {
        hasFile: Array.isArray(backups?.file),
        hasImage: Array.isArray(backups?.image),
        fileCount: backups?.file?.length || 0,
        imageCount: backups?.image?.length || 0
      });

      if (backups?.file?.length > 0 || backups?.image?.length > 0) {
        logger.info(`Sample backup data:`, JSON.stringify(backups?.file?.[0] || backups?.image?.[0]));
      }

      return backups;
    } catch (error) {
      logger.error('Failed to get backups:', error);
      throw error;
    }
  }

  async startFullFileBackup(clientName: string, clientId?: string | number) {
    try {
      logger.info(`Starting full file backup for client: ${clientName} (ID: ${clientId})`);
      logger.info(`clientName type: ${typeof clientName}, value: ${JSON.stringify(clientName)}`);
      logger.info(`clientId type: ${typeof clientId}, value: ${JSON.stringify(clientId)}`);

      const params: any = {};

      // Prefer clientId if available and valid
      if (clientId) {
        const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
        if (!isNaN(numericId) && numericId > 0) {
          params.clientId = numericId;
          logger.info(`Using client ID: ${params.clientId}`);
        } else {
          logger.warn(`Invalid client ID: ${clientId}, falling back to clientName: ${clientName}`);
          params.clientName = String(clientName); // Ensure it's a string
        }
      } else if (clientName) {
        params.clientName = String(clientName); // Ensure it's a string
        logger.info(`Using client name: ${params.clientName}`);
      } else {
        throw new Error('Either clientId or clientName must be provided');
      }

      logger.info(`Calling urbackup-server-api with params: ${JSON.stringify(params)}`);
      const result = await this.api.startFullFileBackup(params);
      logger.info(`Full file backup started successfully for ${clientName}:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to start full file backup for ${clientName}:`, error.message);
      logger.error(`Error details:`, error);
      if (error.message.includes('missing')) {
        throw new Error(`Failed to start backup: Client may not exist or UrBackup user lacks permissions. Ensure the client is properly configured and the UrBackup user has backup rights.`);
      }
      throw new Error(`Failed to start full file backup: ${error.message}`);
    }
  }

  async startIncrementalFileBackup(clientName: string, clientId?: string | number) {
    try {
      logger.info(`Starting incremental file backup for client: ${clientName} (ID: ${clientId})`);
      logger.info(`clientName type: ${typeof clientName}, value: ${JSON.stringify(clientName)}`);
      logger.info(`clientId type: ${typeof clientId}, value: ${JSON.stringify(clientId)}`);

      const params: any = {};

      // Prefer clientId if available and valid
      if (clientId) {
        const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
        if (!isNaN(numericId) && numericId > 0) {
          params.clientId = numericId;
          logger.info(`Using client ID: ${params.clientId}`);
        } else {
          logger.warn(`Invalid client ID: ${clientId}, falling back to clientName: ${clientName}`);
          params.clientName = String(clientName); // Ensure it's a string
        }
      } else if (clientName) {
        params.clientName = String(clientName); // Ensure it's a string
        logger.info(`Using client name: ${params.clientName}`);
      } else {
        throw new Error('Either clientId or clientName must be provided');
      }

      logger.info(`Calling urbackup-server-api with params: ${JSON.stringify(params)}`);
      const result = await this.api.startIncrementalFileBackup(params);
      logger.info(`Incremental file backup started successfully for ${clientName}:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to start incremental file backup for ${clientName}:`, error.message);
      logger.error(`Error details:`, error);
      if (error.message.includes('missing')) {
        throw new Error(`Failed to start backup: Client may not exist or UrBackup user lacks permissions. Ensure the client is properly configured and the UrBackup user has backup rights.`);
      }
      throw new Error(`Failed to start incremental file backup: ${error.message}`);
    }
  }

  async startFullImageBackup(clientName: string, clientId?: string | number) {
    try {
      logger.info(`Starting full image backup for client: ${clientName} (ID: ${clientId})`);
      logger.info(`clientName type: ${typeof clientName}, value: ${JSON.stringify(clientName)}`);
      logger.info(`clientId type: ${typeof clientId}, value: ${JSON.stringify(clientId)}`);

      const params: any = {};
      if (clientId) {
        params.clientId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
      } else {
        params.clientName = String(clientName); // Ensure it's a string
      }

      logger.info(`Calling urbackup-server-api with params: ${JSON.stringify(params)}`);
      const result = await this.api.startFullImageBackup(params);
      logger.info(`Full image backup started successfully for ${clientName}:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to start full image backup for ${clientName}:`, error.message);
      logger.error(`Error details:`, error);
      throw new Error(`Failed to start full image backup: ${error.message}`);
    }
  }

  async startIncrementalImageBackup(clientName: string, clientId?: string | number) {
    try {
      logger.info(`Starting incremental image backup for client: ${clientName} (ID: ${clientId})`);
      logger.info(`clientName type: ${typeof clientName}, value: ${JSON.stringify(clientName)}`);
      logger.info(`clientId type: ${typeof clientId}, value: ${JSON.stringify(clientId)}`);

      const params: any = {};
      if (clientId) {
        params.clientId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
      } else {
        params.clientName = String(clientName); // Ensure it's a string
      }

      logger.info(`Calling urbackup-server-api with params: ${JSON.stringify(params)}`);
      const result = await this.api.startIncrementalImageBackup(params);
      logger.info(`Incremental image backup started successfully for ${clientName}:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to start incremental image backup for ${clientName}:`, error.message);
      logger.error(`Error details:`, error);
      throw new Error(`Failed to start incremental image backup: ${error.message}`);
    }
  }

  async stopActivity(activityId: string) {
    try {
      return await this.api.stopActivity({ id: activityId });
    } catch (error) {
      logger.error('Failed to stop activity:', error);
      throw error;
    }
  }

  async getServerVersion() {
    try {
      return await this.api.getServerVersion();
    } catch (error) {
      logger.error('Failed to get server version:', error);
      throw error;
    }
  }

  async getUsage() {
    try {
      const usage = await this.api.getUsage();
      logger.info('Usage data type:', typeof usage);
      logger.info('Usage is array:', Array.isArray(usage));
      logger.info('Usage length:', Array.isArray(usage) ? usage.length : 'N/A');
      if (Array.isArray(usage) && usage.length > 0) {
        logger.info('First usage entry:', JSON.stringify(usage[0]));
      } else {
        logger.info('Usage data is empty or not an array:', usage);
      }
      return usage;
    } catch (error) {
      logger.error('Failed to get usage:', error);
      throw error;
    }
  }

  async getLogs() {
    try {
      // Note: The urbackup-server-api library doesn't have a getLogs method
      // Return empty array for now - logs would need to be fetched directly from the server
      logger.warn('getLogs called but not supported by urbackup-server-api');
      return [];
    } catch (error) {
      logger.error('Failed to get logs:', error);
      throw error;
    }
  }

  async getLiveLog() {
    try {
      // Note: The urbackup-server-api library doesn't have a getLiveLog method
      // Return empty array for now - logs would need to be fetched directly from the server
      logger.warn('getLiveLog called but not supported by urbackup-server-api');
      return [];
    } catch (error) {
      logger.error('Failed to get live log:', error);
      throw error;
    }
  }

  async getSettings() {
    try {
      return await this.api.getGeneralSettings();
    } catch (error) {
      logger.error('Failed to get settings:', error);
      throw error;
    }
  }

  async setSettings(settings: any) {
    try {
      // The API expects one setting at a time: { key, newValue }
      // We need to call it for each setting
      const results: any[] = [];
      const errors: any[] = [];

      for (const [key, value] of Object.entries(settings)) {
        try {
          // Skip null and undefined values
          if (value === null || value === undefined) {
            logger.info(`Skipping setting ${key}: value is null or undefined`);
            continue;
          }

          // Convert values to appropriate types for UrBackup API
          let apiValue: any;
          if (typeof value === 'boolean') {
            // Keep boolean as-is - UrBackup API expects actual boolean values
            apiValue = value;
          } else if (typeof value === 'object') {
            // Convert objects to JSON strings
            apiValue = JSON.stringify(value);
            logger.info(`Converting object setting ${key} to JSON string`);
          } else {
            // Use primitive values as-is (string, number)
            apiValue = value;
          }

          logger.info(`Setting ${key}: original=${JSON.stringify(value)} (${typeof value}), converted=${apiValue} (${typeof apiValue})`);

          const result = await this.api.setGeneralSettings({ key, newValue: apiValue });
          results.push({ key, value: apiValue, success: result });
          logger.info(`Set setting ${key} = ${apiValue}: ${JSON.stringify(result)}`);
        } catch (error: any) {
          logger.error(`Failed to set setting ${key}:`, error);
          errors.push({ key, error: error.message });
        }
      }

      if (errors.length > 0) {
        logger.warn(`Some settings failed to save:`, errors);
      }

      return {
        success: errors.length === 0,
        results,
        errors: errors.length > 0 ? errors : undefined
      };
    } catch (error) {
      logger.error('Failed to set settings:', error);
      throw error;
    }
  }

  async bulkSetSettings(updates: any) {
    try {
      logger.info('Starting bulk settings update with direct UrBackup API call...');

      // First, we need to login and get a session
      // We'll make direct HTTP calls to bypass the library's broken setGeneralSettings

      const url = `http://${this.serverConfig.host}:${this.serverConfig.port}/x`;

      // Step 1: Login
      logger.info('Step 1: Logging in to UrBackup...');
      const loginParams = new URLSearchParams({
        username: this.serverConfig.username,
        password: this.serverConfig.password
      });

      const loginResponse = await fetch(`${url}?a=login`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'urbstat',
          'Accept': 'application/json'
        },
        body: loginParams.toString()
      });

      const loginData: any = await loginResponse.json();
      if (!loginData.session) {
        throw new Error('Failed to login to UrBackup server');
      }

      const session = loginData.session;
      logger.info('Successfully logged in, session obtained');

      // Step 2: Get current settings
      logger.info('Step 2: Getting current settings...');
      const settingsResponse = await fetch(`${url}?a=settings&sa=general&ses=${session}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'urbstat',
          'Accept': 'application/json'
        }
      });

      const currentSettings: any = await settingsResponse.json();
      logger.info(`Got ${Object.keys(currentSettings).length} current settings`);

      // Step 3: Apply all updates to the settings object
      logger.info(`Step 3: Applying ${Object.keys(updates).length} updates...`);
      for (const [key, value] of Object.entries(updates)) {
        if (value !== null && value !== undefined) {
          logger.info(`Updating ${key} from "${currentSettings[key]}" to "${value}"`);
          currentSettings[key] = value;
        }
      }

      // Step 4: Add the save action and save
      currentSettings.sa = 'general_save';

      logger.info('Step 4: Saving all settings in one operation...');
      const saveParams = new URLSearchParams();
      for (const [key, value] of Object.entries(currentSettings)) {
        // Convert value to string for URLSearchParams
        if (typeof value === 'boolean') {
          saveParams.append(key, value ? 'true' : 'false');
        } else if (value !== null && value !== undefined) {
          saveParams.append(key, String(value));
        }
      }

      const saveResponse = await fetch(`${url}?ses=${session}`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
          'User-Agent': 'urbstat',
          'Accept': 'application/json'
        },
        body: saveParams.toString()
      });

      const saveResult: any = await saveResponse.json();
      logger.info('Save response:', JSON.stringify(saveResult));

      if (saveResult?.saved_ok === true) {
        logger.info('✅ Bulk save successful!');
        return {
          success: true,
          results: Object.keys(updates).map(key => ({ key, success: true })),
          errors: []
        };
      } else {
        logger.error('❌ Bulk save failed:', saveResult);
        return {
          success: false,
          results: [],
          errors: [{ error: 'UrBackup returned saved_ok = false' }]
        };
      }
    } catch (error: any) {
      logger.error('Failed to bulk set settings:', error);
      throw error;
    }
  }

  async getClientSettings(clientId: string) {
    try {
      const result = await this.api.getClientSettings({ clientId: parseInt(clientId) });
      logger.info(`Raw client settings from UrBackup API for client ${clientId}:`);
      logger.info(`Type: ${typeof result}, IsArray: ${Array.isArray(result)}`);
      if (Array.isArray(result)) {
        logger.info(`Array length: ${result.length}`);
        if (result.length > 0) {
          logger.info(`First element keys: ${Object.keys(result[0]).join(', ')}`);
          logger.info(`Sample values: interval_incr=${result[0].interval_incr}, interval_full=${result[0].interval_full}, backup_window_incr_file=${result[0].backup_window_incr_file}`);
        }
      }
      logger.info(JSON.stringify(result, null, 2));
      return result;
    } catch (error) {
      logger.error('Failed to get client settings:', error);
      throw error;
    }
  }

  async setClientSettings(clientId: string, newSettings: any) {
    try {
      const id = parseInt(clientId);

      // The urbackup-server-api setClientSettings only handles one setting at a time
      // We need to call it for each setting
      const results: Array<{ key: string; success: any }> = [];
      const errors: Array<{ key: string; error: any }> = [];

      for (const [key, value] of Object.entries(newSettings)) {
        try {
          const result = await this.api.setClientSettings({
            clientId: id,
            key: key,
            newValue: value
          });
          results.push({ key, success: result });
        } catch (error: any) {
          logger.error(`Failed to set setting ${key}:`, error);
          errors.push({ key, error: error.message });
        }
      }

      if (errors.length > 0) {
        logger.warn(`Some settings failed to save:`, errors);
      }

      return {
        success: errors.length === 0,
        results,
        errors: errors.length > 0 ? errors : undefined
      };
    } catch (error) {
      logger.error('Failed to set client settings:', error);
      throw error;
    }
  }

  async browseClientFilesystem(clientId: string, path: string = '') {
    try {
      // Try to get live filesystem from client
      const url = `http://${this.serverConfig.host}:${this.serverConfig.port}/x`;

      // Login to get session
      const loginParams = new URLSearchParams({
        'a': 'login',
        'username': this.serverConfig.username,
        'password': this.serverConfig.password
      });

      const loginResponse = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: loginParams.toString()
      });

      if (!loginResponse.ok) {
        throw new Error(`Failed to login: ${loginResponse.statusText}`);
      }

      const loginData: any = await loginResponse.json();
      if (!loginData.session) {
        throw new Error('Failed to get session from login');
      }

      const sessionId: string = loginData.session;

      // Try browsing client filesystem with various API actions
      // The UrBackup web interface uses these to browse client dirs
      const browseParams = new URLSearchParams({
        'a': 'dir',
        'clientid': clientId,
        'path': path,
        'ses': sessionId
      });

      logger.info(`Attempting to browse client ${clientId} filesystem at path: ${path}`);

      const browseResponse = await fetch(url, {
        method: 'POST',
        headers: { 'Content-Type': 'application/x-www-form-urlencoded' },
        body: browseParams.toString()
      });

      if (!browseResponse.ok) {
        throw new Error(`Failed to browse client filesystem: ${browseResponse.statusText}`);
      }

      const data = await browseResponse.json();
      logger.info(`Browse client filesystem response:`, JSON.stringify(data).substring(0, 200));

      return data;
    } catch (error) {
      logger.error('Failed to browse client filesystem:', error);
      throw error;
    }
  }

  async browseBackupFiles(clientId: string, backupId: string, path: string = '/') {
    try {
      // Ensure we're logged in by making a status call
      // This will establish a session if not already logged in
      await this.api.getStatus();

      // Now make the backup browse request
      // UrBackup uses session-based auth, and the library handles the session internally
      // We need to access the internal session, but since it's private, we'll use a workaround
      // by making a raw POST request with login first

      const url = `http://${this.serverConfig.host}:${this.serverConfig.port}/x`;

      // First login to get session
      const loginParams = new URLSearchParams({
        'a': 'login',
        'username': this.serverConfig.username,
        'password': this.serverConfig.password
      });

      logger.info(`Logging in to UrBackup server...`);
      const loginResponse = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: loginParams.toString()
      });

      if (!loginResponse.ok) {
        throw new Error(`Failed to login: ${loginResponse.statusText}`);
      }

      const loginData: any = await loginResponse.json();
      logger.info(`Login response:`, loginData);

      if (!loginData.session) {
        throw new Error('Failed to get session from login');
      }

      const sessionId: string = loginData.session;

      // Now browse the backup files with the session
      const browseParams = new URLSearchParams({
        'a': 'backups',
        'sa': 'files',
        'clientid': clientId,
        'backupid': backupId,
        'path': path,
        'ses': sessionId
      });

      logger.info(`Browsing backup files with session: clientid=${clientId}, backupid=${backupId}, path=${path}`);

      const browseResponse = await fetch(url, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/x-www-form-urlencoded',
        },
        body: browseParams.toString()
      });

      if (!browseResponse.ok) {
        throw new Error(`Failed to browse backup files: ${browseResponse.statusText}`);
      }

      const data = await browseResponse.json();
      logger.info(`Browse response:`, JSON.stringify(data).substring(0, 200));

      return data;
    } catch (error) {
      logger.error('Failed to browse backup files:', error);
      throw error;
    }
  }

  async addClient(clientName: string) {
    try {
      logger.info(`Adding new client: ${clientName}`);
      const result = await this.api.addClient({ clientName: String(clientName) });
      logger.info(`Client ${clientName} added successfully:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to add client ${clientName}:`, error.message);
      throw new Error(`Failed to add client: ${error.message}`);
    }
  }

  async removeClient(clientId: string | number) {
    try {
      logger.info(`Removing client with ID: ${clientId}`);
      const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
      const result = await this.api.removeClient({ clientId: numericId });
      logger.info(`Client ${clientId} removed successfully:`, result);
      return result;
    } catch (error: any) {
      logger.error(`Failed to remove client ${clientId}:`, error.message);
      throw new Error(`Failed to remove client: ${error.message}`);
    }
  }

  async getClientAuthkey(clientId: string | number) {
    try {
      logger.info(`Getting authentication key for client ID: ${clientId}`);
      const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;
      const authkey = await this.api.getClientAuthkey({ clientId: numericId });
      logger.info(`Retrieved auth key for client ${clientId} (length: ${authkey.length})`);
      return authkey;
    } catch (error: any) {
      logger.error(`Failed to get auth key for client ${clientId}:`, error.message);
      throw new Error(`Failed to get client authentication key: ${error.message}`);
    }
  }

  async updateClientName(clientId: string | number, newName: string) {
    try {
      logger.info(`Updating client ${clientId} name to: ${newName}`);
      const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;

      // Use setClientSettings to update the client name
      const result = await this.api.setClientSettings({
        clientId: numericId,
        key: 'name',
        newValue: newName
      });

      logger.info(`Client ${clientId} name updated successfully`);
      return result;
    } catch (error: any) {
      logger.error(`Failed to update client name:`, error.message);
      throw new Error(`Failed to update client name: ${error.message}`);
    }
  }

  async regenerateClientAuthkey(clientId: string | number): Promise<string> {
    try {
      logger.info(`Regenerating authentication key for client ID: ${clientId}`);
      const numericId = typeof clientId === 'string' ? parseInt(clientId) : clientId;

      // Generate a new random 64-character hex authentication key
      const newAuthkey = Array.from({ length: 64 }, () =>
        Math.floor(Math.random() * 16).toString(16)
      ).join('');

      // Update the client's auth key using setClientSettings
      await this.api.setClientSettings({
        clientId: numericId,
        key: 'internet_authkey',
        newValue: newAuthkey
      });

      logger.info(`Authentication key regenerated for client ${clientId}`);
      return newAuthkey;
    } catch (error: any) {
      logger.error(`Failed to regenerate auth key for client ${clientId}:`, error.message);
      throw new Error(`Failed to regenerate client authentication key: ${error.message}`);
    }
  }

  /**
   * Get the UrBackup server config (for direct API access)
   */
  getServerConfig(): UrBackupServer {
    return this.serverConfig;
  }

  /**
   * Get the internal API instance (for accessing authenticated sessions)
   */
  getApiInstance(): UrbackupServer {
    return this.api;
  }
}
