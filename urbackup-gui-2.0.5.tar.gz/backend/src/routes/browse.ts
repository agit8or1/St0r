import { Router } from 'express';
import { browseBackup, getFileBackups, getDownloadToken } from '../controllers/browse.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Get file backups list for a client
router.get('/backups', getFileBackups);

// Browse files in a specific backup
router.get('/files', browseBackup);

// Get download token for a file
router.get('/download', getDownloadToken);

export default router;
