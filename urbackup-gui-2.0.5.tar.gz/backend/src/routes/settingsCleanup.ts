import { Router } from 'express';
import { cleanupCorruptedSettings } from '../controllers/settingsCleanup.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Cleanup corrupted settings (admin only)
router.post('/cleanup', cleanupCorruptedSettings);

export default router;
