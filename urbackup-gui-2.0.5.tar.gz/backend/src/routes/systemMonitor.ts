import { Router } from 'express';
import { getSystemMetrics, testServerLatency } from '../controllers/systemMonitor.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All system monitor routes require authentication
router.use(authenticate);

router.get('/metrics', getSystemMetrics);
router.get('/latency/:serverId', testServerLatency);

export default router;
