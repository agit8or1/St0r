import { Router } from 'express';
import { getTotalStorage, getServerStorage } from '../controllers/storage.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All storage routes require authentication
router.use(authenticate);

router.get('/total', getTotalStorage);
router.get('/server', getServerStorage);

export default router;
