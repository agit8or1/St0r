// Map UrBackup numeric status codes to human-readable strings
// Based on UrBackup Server API documentation
export function getClientStatusText(statusCode: string | number | undefined): string {
  // Handle undefined/null
  if (statusCode === undefined || statusCode === null) {
    return 'Unknown';
  }

  // Handle string "Unknown"
  if (typeof statusCode === 'string' && statusCode.toLowerCase() === 'unknown') {
    return 'Unknown';
  }

  // Convert to number
  const status = typeof statusCode === 'string' ? parseInt(statusCode) : statusCode;

  // Check if conversion failed
  if (isNaN(status)) {
    return `Unknown`;
  }

  switch (status) {
    case 0:
      return 'Idle';
    case 1:
      return 'Waiting for backup window';
    case 2:
      return 'Starting backup';
    case 3:
      return 'Scanning for changes';
    case 4:
      return 'Transferring files';
    case 5:
      return 'Resuming backup';
    case 6:
      return 'Image backup running';
    case 7:
      return 'Incremental file backup';
    case 8:
      return 'Full file backup';
    case 9:
      return 'Full image backup';
    case 10:
      return 'Incremental image backup';
    case 11:
      return 'Waiting for client';
    case 12:
      return 'No paths configured';
    default:
      return `Status ${status}`;
  }
}

// Get status color based on status code
export function getClientStatusColor(statusCode: string | number): 'green' | 'blue' | 'yellow' | 'gray' {
  const status = typeof statusCode === 'string' ? parseInt(statusCode) : statusCode;

  if (status === 0) return 'green'; // Idle/OK
  if (status >= 1 && status <= 11) return 'blue'; // Active/backup in progress
  if (status === 12) return 'yellow'; // Warning - no paths configured
  return 'gray'; // Unknown
}
