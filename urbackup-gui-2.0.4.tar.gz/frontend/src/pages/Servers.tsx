import { useEffect, useState } from 'react';
import { Plus, Edit2, Trash2, CheckCircle, XCircle, HardDrive, Cpu, Database, Clock, Activity, Download } from 'lucide-react';
import { Layout } from '../components/Layout';
import { Loading } from '../components/Loading';
import { api } from '../services/api';
import type { UrBackupServer, CreateServerRequest, SystemMetrics } from '../types';
import { formatBytes } from '../utils/format';

export function Servers() {
  const [servers, setServers] = useState<UrBackupServer[]>([]);
  const [loading, setLoading] = useState(true);
  const [showModal, setShowModal] = useState(false);
  const [editingServer, setEditingServer] = useState<UrBackupServer | null>(null);
  const [diskUsage, setDiskUsage] = useState<number>(0);
  const [serverStats, setServerStats] = useState<Map<number, { used: number; clientCount: number; error?: string }>>(new Map());
  const [systemMetrics, setSystemMetrics] = useState<SystemMetrics | null>(null);
  const [formData, setFormData] = useState<CreateServerRequest>({
    name: '',
    host: '',
    port: 55414,
    username: 'admin',
    password: '',
    isDefault: false,
  });
  const [testingConnection, setTestingConnection] = useState(false);
  const [connectionTest, setConnectionTest] = useState<{ success: boolean; message: string } | null>(null);

  useEffect(() => {
    loadServers();
    loadUsage();
    loadSystemMetrics();

    // Refresh metrics every 10 seconds
    const interval = setInterval(loadSystemMetrics, 10000);
    return () => clearInterval(interval);
  }, []);

  const loadServers = async () => {
    try {
      const data = await api.getServers();
      setServers(data);
    } catch (err) {
      console.error('Failed to load servers:', err);
    } finally {
      setLoading(false);
    }
  };

  const loadUsage = async () => {
    try {
      const storageData = await api.getTotalStorage();
      setDiskUsage(storageData.used);

      // Build per-server stats map
      const statsMap = new Map<number, { used: number; clientCount: number; error?: string }>();

      // Get client counts per server
      for (const serverInfo of storageData.servers) {
        try {
          const clients = await api.getClients(serverInfo.serverId);
          statsMap.set(serverInfo.serverId, {
            used: serverInfo.used,
            clientCount: clients.length,
            error: serverInfo.error
          });
        } catch (err) {
          statsMap.set(serverInfo.serverId, {
            used: serverInfo.used,
            clientCount: 0,
            error: serverInfo.error || 'Failed to get client count'
          });
        }
      }

      setServerStats(statsMap);
    } catch (err) {
      console.error('Failed to load storage:', err);
    }
  };

  const loadSystemMetrics = async () => {
    try {
      const metrics = await api.getSystemMetrics();
      setSystemMetrics(metrics);
    } catch (err) {
      console.error('Failed to load system metrics:', err);
    }
  };

  const handleTestConnection = async () => {
    setTestingConnection(true);
    setConnectionTest(null);

    try {
      const result = await api.testConnection(
        formData.host,
        formData.port,
        formData.username,
        formData.password
      );

      if (result.success) {
        setConnectionTest({
          success: true,
          message: `Connection successful! Server version: ${result.version?.version_string || 'Unknown'}`,
        });
      } else {
        setConnectionTest({
          success: false,
          message: result.error || 'Connection failed',
        });
      }
    } catch (err: any) {
      setConnectionTest({
        success: false,
        message: err.response?.data?.error || 'Connection test failed',
      });
    } finally {
      setTestingConnection(false);
    }
  };

  const downloadBackupScript = async () => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch('/api/documentation/download/Backup-UrBackup-Database.sh', {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Download failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = 'Backup-UrBackup-Database.sh';
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download backup script. Please try again.');
    }
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();

    try {
      if (editingServer) {
        await api.updateServer(editingServer.id, formData);
      } else {
        await api.createServer(formData);
      }

      setShowModal(false);
      setEditingServer(null);
      setConnectionTest(null);
      loadServers();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to save server');
    }
  };

  const handleEdit = (server: UrBackupServer) => {
    setEditingServer(server);
    setFormData({
      name: server.name,
      host: server.host,
      port: server.port,
      username: server.username,
      password: '',
      isDefault: server.isDefault,
    });
    setConnectionTest(null);
    setShowModal(true);
  };

  const handleDelete = async (id: number) => {
    if (!confirm('Are you sure you want to delete this server?')) return;

    try {
      await api.deleteServer(id);
      loadServers();
    } catch (err: any) {
      alert(err.response?.data?.error || 'Failed to delete server');
    }
  };

  const handleAddNew = () => {
    setEditingServer(null);
    setFormData({
      name: '',
      host: '',
      port: 55414,
      username: 'admin',
      password: '',
      isDefault: false,
    });
    setConnectionTest(null);
    setShowModal(true);
  };

  if (loading) {
    return (
      <Layout>
        <Loading />
      </Layout>
    );
  }

  return (
    <Layout>
      <div className="space-y-6">
        <div className="flex items-center justify-between">
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Servers</h1>
            <p className="mt-1 text-sm text-gray-600 dark:text-gray-400">
              Manage your UrBackup server connections
            </p>
          </div>
          <button onClick={handleAddNew} className="btn btn-primary flex items-center gap-2">
            <Plus className="h-4 w-4" />
            Add Server
          </button>
        </div>

        {/* System Metrics Grid */}
        {systemMetrics && (
          <div className="space-y-4">
            <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100">
              St0r Server Statistics
            </h2>
            <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
            {/* CPU Usage */}
            <div className="card bg-gradient-to-br from-blue-50 to-cyan-50 dark:from-blue-900/20 dark:to-cyan-900/20">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-blue-600 p-3">
                  <Cpu className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">CPU Usage</p>
                  <p className="text-2xl font-bold text-blue-600 dark:text-blue-400 mt-1">
                    {systemMetrics.cpu.usage.toFixed(1)}%
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    {systemMetrics.cpu.cores} cores
                  </p>
                </div>
              </div>
              {/* CPU Progress Bar */}
              <div className="mt-3 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700">
                <div
                  className="h-2 rounded-full bg-blue-600 dark:bg-blue-500 transition-all duration-300"
                  style={{ width: `${Math.min(systemMetrics.cpu.usage, 100)}%` }}
                />
              </div>
            </div>

            {/* Memory Usage */}
            <div className="card bg-gradient-to-br from-green-50 to-emerald-50 dark:from-green-900/20 dark:to-emerald-900/20">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-green-600 p-3">
                  <Activity className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Memory</p>
                  <p className="text-2xl font-bold text-green-600 dark:text-green-400 mt-1">
                    {systemMetrics.memory.usagePercent.toFixed(1)}%
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    {formatBytes(systemMetrics.memory.used)} / {formatBytes(systemMetrics.memory.total)}
                  </p>
                </div>
              </div>
              {/* Memory Progress Bar */}
              <div className="mt-3 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700">
                <div
                  className="h-2 rounded-full bg-green-600 dark:bg-green-500 transition-all duration-300"
                  style={{ width: `${Math.min(systemMetrics.memory.usagePercent, 100)}%` }}
                />
              </div>
            </div>

            {/* Disk Usage */}
            <div className="card bg-gradient-to-br from-orange-50 to-amber-50 dark:from-orange-900/20 dark:to-amber-900/20">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-orange-600 p-3">
                  <Database className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Disk Usage</p>
                  <p className="text-2xl font-bold text-orange-600 dark:text-orange-400 mt-1">
                    {systemMetrics.disk.usagePercent}%
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    {formatBytes(systemMetrics.disk.used)} / {formatBytes(systemMetrics.disk.total)}
                  </p>
                </div>
              </div>
              {/* Disk Progress Bar */}
              <div className="mt-3 h-2 w-full rounded-full bg-gray-200 dark:bg-gray-700">
                <div
                  className="h-2 rounded-full bg-orange-600 dark:bg-orange-500 transition-all duration-300"
                  style={{ width: `${Math.min(systemMetrics.disk.usagePercent, 100)}%` }}
                />
              </div>
            </div>

            {/* Uptime */}
            <div className="card bg-gradient-to-br from-purple-50 to-pink-50 dark:from-purple-900/20 dark:to-pink-900/20">
              <div className="flex items-center gap-3">
                <div className="rounded-full bg-purple-600 p-3">
                  <Clock className="h-6 w-6 text-white" />
                </div>
                <div className="flex-1">
                  <p className="text-sm font-medium text-gray-600 dark:text-gray-400">Uptime</p>
                  <p className="text-2xl font-bold text-purple-600 dark:text-purple-400 mt-1">
                    {Math.floor(systemMetrics.uptime / 86400)}d {Math.floor((systemMetrics.uptime % 86400) / 3600)}h
                  </p>
                  <p className="text-xs text-gray-500 dark:text-gray-500 mt-1">
                    {systemMetrics.hostname}
                  </p>
                </div>
              </div>
            </div>
          </div>
          </div>
        )}

        {/* UrBackup Servers */}
        <div>
          <h2 className="text-xl font-semibold text-gray-900 dark:text-gray-100 mb-4">
            UrBackup Servers
          </h2>
        {/* Backup Storage Summary */}
        <div className="card bg-gradient-to-br from-purple-50 to-blue-50 dark:from-purple-900/20 dark:to-blue-900/20">
          <div className="flex items-center gap-4">
            <div className="rounded-full bg-purple-600 p-4">
              <HardDrive className="h-8 w-8 text-white" />
            </div>
            <div className="flex-1">
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">Backup Storage</h3>
              {diskUsage > 0 ? (
                <>
                  <p className="text-3xl font-bold text-purple-600 dark:text-purple-400 mt-1">
                    {formatBytes(diskUsage)}
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    Total used across all backup servers
                  </p>
                </>
              ) : (
                <>
                  <p className="text-lg text-gray-500 dark:text-gray-400 mt-1">
                    No usage data available
                  </p>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mt-2">
                    Usage statistics will appear after backups complete
                  </p>
                </>
              )}
            </div>
          </div>
        </div>

        {/* Server List */}
        {servers.length === 0 ? (
          <div className="card text-center py-12">
            <p className="text-gray-600">No servers configured yet.</p>
            <button onClick={handleAddNew} className="btn btn-primary mt-4">
              Add Your First Server
            </button>
          </div>
        ) : (
          <div className="grid gap-4">
            {servers.map((server) => {
              const stats = serverStats.get(server.id);
              return (
              <div key={server.id} className="card">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1">
                    <div className="flex items-center gap-2">
                      <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100">
                        {server.name}
                      </h3>
                      {server.isDefault && (
                        <span className="rounded bg-primary-100 dark:bg-primary-900 px-2 py-1 text-xs font-medium text-primary-700 dark:text-primary-300">
                          Default
                        </span>
                      )}
                      {server.isActive ? (
                        <CheckCircle className="h-4 w-4 text-green-600 dark:text-green-400" />
                      ) : (
                        <XCircle className="h-4 w-4 text-red-600 dark:text-red-400" />
                      )}
                    </div>
                    <div className="mt-2 space-y-1 text-sm text-gray-600 dark:text-gray-400">
                      <p>Host: {server.host}:{server.port}</p>
                      <p>Username: {server.username}</p>
                    </div>

                    {/* Server Statistics */}
                    {stats && (
                      <div className="mt-4 grid grid-cols-2 gap-3">
                        <div className="flex items-center gap-2 p-2 bg-blue-50 dark:bg-blue-900/20 rounded">
                          <Database className="h-4 w-4 text-blue-600 dark:text-blue-400" />
                          <div>
                            <p className="text-xs text-gray-600 dark:text-gray-400">Clients</p>
                            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{stats.clientCount}</p>
                          </div>
                        </div>
                        <div className="flex items-center gap-2 p-2 bg-purple-50 dark:bg-purple-900/20 rounded">
                          <HardDrive className="h-4 w-4 text-purple-600 dark:text-purple-400" />
                          <div>
                            <p className="text-xs text-gray-600 dark:text-gray-400">Storage Used</p>
                            <p className="text-sm font-semibold text-gray-900 dark:text-gray-100">{formatBytes(stats.used)}</p>
                          </div>
                        </div>
                      </div>
                    )}
                    {stats?.error && (
                      <p className="mt-2 text-sm text-red-600 dark:text-red-400">{stats.error}</p>
                    )}
                  </div>
                  <div className="flex gap-2 flex-wrap">
                    <button
                      onClick={downloadBackupScript}
                      className="btn bg-purple-600 hover:bg-purple-700 text-white flex items-center gap-2"
                      title="Download database backup script for this server"
                    >
                      <Database className="h-4 w-4" />
                      Backup DB
                    </button>
                    <button
                      onClick={() => handleEdit(server)}
                      className="btn btn-secondary flex items-center gap-2"
                    >
                      <Edit2 className="h-4 w-4" />
                      Edit
                    </button>
                    <button
                      onClick={() => handleDelete(server.id)}
                      className="btn btn-danger flex items-center gap-2"
                    >
                      <Trash2 className="h-4 w-4" />
                      Delete
                    </button>
                  </div>
                </div>
              </div>
            )})}
          </div>
        )}
        </div>
      </div>

      {/* Modal */}
      {showModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black bg-opacity-50 p-4">
          <div className="w-full max-w-md rounded-lg bg-white p-6">
            <h2 className="text-xl font-bold text-gray-900">
              {editingServer ? 'Edit Server' : 'Add Server'}
            </h2>

            <form onSubmit={handleSubmit} className="mt-4 space-y-4">
              <div>
                <label className="label">Name</label>
                <input
                  type="text"
                  value={formData.name}
                  onChange={(e) => setFormData({ ...formData, name: e.target.value })}
                  className="input"
                  required
                />
              </div>

              <div>
                <label className="label">Host</label>
                <input
                  type="text"
                  value={formData.host}
                  onChange={(e) => setFormData({ ...formData, host: e.target.value })}
                  className="input"
                  placeholder="192.168.1.100 or backup.example.com"
                  required
                />
              </div>

              <div>
                <label className="label">Port</label>
                <input
                  type="number"
                  value={formData.port}
                  onChange={(e) =>
                    setFormData({ ...formData, port: parseInt(e.target.value) })
                  }
                  className="input"
                  required
                />
              </div>

              <div>
                <label className="label">Username</label>
                <input
                  type="text"
                  value={formData.username}
                  onChange={(e) => setFormData({ ...formData, username: e.target.value })}
                  className="input"
                  required
                />
              </div>

              <div>
                <label className="label">
                  Password {editingServer && '(leave blank to keep existing)'}
                </label>
                <input
                  type="password"
                  value={formData.password}
                  onChange={(e) => setFormData({ ...formData, password: e.target.value })}
                  className="input"
                  required={!editingServer}
                />
              </div>

              <div className="flex items-center gap-2">
                <input
                  type="checkbox"
                  id="isDefault"
                  checked={formData.isDefault}
                  onChange={(e) =>
                    setFormData({ ...formData, isDefault: e.target.checked })
                  }
                  className="h-4 w-4"
                />
                <label htmlFor="isDefault" className="text-sm text-gray-700">
                  Set as default server
                </label>
              </div>

              {connectionTest && (
                <div
                  className={`flex items-center gap-2 rounded-lg p-3 text-sm ${
                    connectionTest.success
                      ? 'bg-green-50 text-green-700'
                      : 'bg-red-50 text-red-700'
                  }`}
                >
                  {connectionTest.success ? (
                    <CheckCircle className="h-4 w-4" />
                  ) : (
                    <XCircle className="h-4 w-4" />
                  )}
                  {connectionTest.message}
                </div>
              )}

              <div className="flex gap-2">
                <button
                  type="button"
                  onClick={handleTestConnection}
                  className="btn btn-secondary flex-1"
                  disabled={testingConnection}
                >
                  {testingConnection ? 'Testing...' : 'Test Connection'}
                </button>
                <button
                  type="button"
                  onClick={() => setShowModal(false)}
                  className="btn btn-secondary flex-1"
                >
                  Cancel
                </button>
                <button type="submit" className="btn btn-primary flex-1">
                  Save
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </Layout>
  );
}
