import { query } from '../config/database.js';
import { RowDataPacket, ResultSetHeader } from 'mysql2';

export interface UrBackupServer {
  id: number;
  name: string;
  host: string;
  port: number;
  fqdn: string | null;
  username: string;
  password: string;
  is_default: boolean;
  is_active: boolean;
  created_at: Date;
  updated_at: Date;
}

export interface ServerRow extends RowDataPacket, UrBackupServer {}

export async function getAllServers(): Promise<UrBackupServer[]> {
  return await query<ServerRow[]>(
    'SELECT * FROM urbackup_servers WHERE is_active = TRUE ORDER BY is_default DESC, name ASC'
  );
}

export async function getServerById(id: number): Promise<UrBackupServer | null> {
  const servers = await query<ServerRow[]>(
    'SELECT * FROM urbackup_servers WHERE id = ? AND is_active = TRUE',
    [id]
  );
  return servers.length > 0 ? servers[0] : null;
}

export async function getDefaultServer(): Promise<UrBackupServer | null> {
  const servers = await query<ServerRow[]>(
    'SELECT * FROM urbackup_servers WHERE is_default = TRUE AND is_active = TRUE LIMIT 1'
  );
  return servers.length > 0 ? servers[0] : null;
}

export async function createServer(
  name: string,
  host: string,
  port: number,
  fqdn: string | null,
  username: string,
  password: string,
  isDefault: boolean = false
): Promise<number> {
  // If this is set as default, unset all others
  if (isDefault) {
    await query('UPDATE urbackup_servers SET is_default = FALSE');
  }

  const result = await query<ResultSetHeader>(
    'INSERT INTO urbackup_servers (name, host, port, fqdn, username, password, is_default) VALUES (?, ?, ?, ?, ?, ?, ?)',
    [name, host, port, fqdn, username, password, isDefault]
  );
  return result.insertId;
}

export async function updateServer(
  id: number,
  name: string,
  host: string,
  port: number,
  fqdn: string | null,
  username: string,
  password: string,
  isDefault: boolean
): Promise<void> {
  // If this is set as default, unset all others
  if (isDefault) {
    await query('UPDATE urbackup_servers SET is_default = FALSE WHERE id != ?', [id]);
  }

  await query(
    'UPDATE urbackup_servers SET name = ?, host = ?, port = ?, fqdn = ?, username = ?, password = ?, is_default = ? WHERE id = ?',
    [name, host, port, fqdn, username, password, isDefault, id]
  );
}

export async function deleteServer(id: number): Promise<void> {
  await query('UPDATE urbackup_servers SET is_active = FALSE WHERE id = ?', [id]);
}
