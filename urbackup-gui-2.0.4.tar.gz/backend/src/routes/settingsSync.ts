import { Router } from 'express';
import {
  importSettings,
  cleanupDatabase,
  syncToUrBackup,
  fullCleanupAndSync
} from '../controllers/settingsSync.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Import settings from UrBackup to database
router.post('/import', importSettings);

// Clean corrupted settings in database
router.post('/cleanup-db', cleanupDatabase);

// Sync cleaned settings from database to UrBackup
router.post('/sync-to-urbackup', syncToUrBackup);

// One-step: Import, Clean, and Sync
router.post('/full-cleanup', fullCleanupAndSync);

export default router;
