import express from 'express';
import { authenticate } from '../middleware/auth.js';
import { browseClientRoot, browseClientDirectory, getClientVolumes, getClientInfo } from '../controllers/clientFilesystem.js';

const router = express.Router();

// All routes require authentication
router.use(authenticate);

// Browse client filesystem root (drives/top-level)
router.get('/:clientId/browse/root', browseClientRoot);

// Browse client subdirectory
router.get('/:clientId/browse/directory', browseClientDirectory);

// Get client volumes (from existing image backups and settings)
router.get('/:clientId/volumes', getClientVolumes);

// Get client info (OS, status, etc.)
router.get('/:clientId/info', getClientInfo);

export default router;
