import { Request, Response } from 'express';
import axios from 'axios';
import { getDefaultServer } from '../models/server.js';
import { logger } from '../utils/logger.js';

/**
 * Browse files in a backup
 */
export async function browseBackup(req: Request, res: Response) {
  try {
    const { clientId, backupId, path } = req.query;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId || !backupId) {
      res.status(400).json({ error: 'clientId and backupId are required' });
      return;
    }

    const server = serverId
      ? await getDefaultServer()
      : await getDefaultServer();

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const url = `http://${server.host}:${server.port}`;

    // Login to get session
    const loginResponse = await axios.post(`${url}?a=login`, {
      username: server.username,
      password: server.password,
      plainpw: true
    }, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    const sessionId = (loginResponse.data as any).session;
    if (!sessionId) {
      throw new Error('Failed to get session ID');
    }

    // Browse backup files
    const browseParams = {
      a: 'backups',
      sa: 'filelist',
      clientid: clientId,
      backupid: backupId,
      path: path || '/',
      ses: sessionId
    };

    const browseResponse = await axios.get(url, {
      params: browseParams
    });

    res.json(browseResponse.data);
  } catch (error: any) {
    logger.error('Failed to browse backup:', error);
    res.status(500).json({
      error: 'Failed to browse backup',
      message: error.message
    });
  }
}

/**
 * Get file backups for browsing
 */
export async function getFileBackups(req: Request, res: Response) {
  try {
    const { clientName, clientId } = req.query;
    const serverId = req.query.serverId as string | undefined;

    if (!clientName && !clientId) {
      res.status(400).json({ error: 'clientName or clientId is required' });
      return;
    }

    const server = serverId
      ? await getDefaultServer()
      : await getDefaultServer();

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const url = `http://${server.host}:${server.port}`;

    // Login to get session
    const loginResponse = await axios.post(`${url}?a=login`, {
      username: server.username,
      password: server.password,
      plainpw: true
    }, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    const sessionId = (loginResponse.data as any).session;
    if (!sessionId) {
      throw new Error('Failed to get session ID');
    }

    // Get backups list
    const backupsParams: any = {
      a: 'backups',
      sa: 'backups',
      ses: sessionId
    };

    if (clientName) {
      backupsParams.clientname = clientName;
    } else if (clientId) {
      backupsParams.clientid = clientId;
    }

    const backupsResponse = await axios.get(url, {
      params: backupsParams
    });

    res.json(backupsResponse.data);
  } catch (error: any) {
    logger.error('Failed to get file backups:', error);
    res.status(500).json({
      error: 'Failed to get file backups',
      message: error.message
    });
  }
}

/**
 * Get download token for a file
 */
export async function getDownloadToken(req: Request, res: Response) {
  try {
    const { clientId, backupId, path } = req.query;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId || !backupId || !path) {
      res.status(400).json({ error: 'clientId, backupId, and path are required' });
      return;
    }

    const server = serverId
      ? await getDefaultServer()
      : await getDefaultServer();

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const url = `http://${server.host}:${server.port}`;

    // Login to get session
    const loginResponse = await axios.post(`${url}?a=login`, {
      username: server.username,
      password: server.password,
      plainpw: true
    }, {
      headers: {
        'Content-Type': 'application/x-www-form-urlencoded'
      }
    });

    const sessionId = (loginResponse.data as any).session;
    if (!sessionId) {
      throw new Error('Failed to get session ID');
    }

    // Get download token
    const downloadParams = {
      a: 'download_files',
      clientid: clientId,
      backupid: backupId,
      path: path,
      ses: sessionId
    };

    const downloadResponse = await axios.get(url, {
      params: downloadParams
    });

    const responseData = downloadResponse.data as any;
    res.json({
      ...responseData,
      serverUrl: url
    });
  } catch (error: any) {
    logger.error('Failed to get download token:', error);
    res.status(500).json({
      error: 'Failed to get download token',
      message: error.message
    });
  }
}
