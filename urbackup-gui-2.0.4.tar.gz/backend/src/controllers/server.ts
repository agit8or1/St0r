import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import * as serverModel from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';

export async function getServers(req: AuthRequest, res: Response): Promise<void> {
  try {
    const servers = await serverModel.getAllServers();

    // Don't send passwords to the client
    const sanitized = servers.map(s => ({
      id: s.id,
      name: s.name,
      host: s.host,
      port: s.port,
      username: s.username,
      isDefault: s.is_default,
      isActive: s.is_active,
      createdAt: s.created_at,
      updatedAt: s.updated_at,
    }));

    res.json(sanitized);
  } catch (error) {
    logger.error('Failed to get servers:', error);
    res.status(500).json({ error: 'Failed to retrieve servers' });
  }
}

export async function getServer(req: AuthRequest, res: Response): Promise<void> {
  try {
    const id = parseInt(req.params.id);
    const server = await serverModel.getServerById(id);

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    res.json({
      id: server.id,
      name: server.name,
      host: server.host,
      port: server.port,
      username: server.username,
      isDefault: server.is_default,
      isActive: server.is_active,
      createdAt: server.created_at,
      updatedAt: server.updated_at,
    });
  } catch (error) {
    logger.error('Failed to get server:', error);
    res.status(500).json({ error: 'Failed to retrieve server' });
  }
}

export async function createServer(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { name, host, port, username, password, isDefault } = req.body;

    if (!name || !host || !port || !username || !password) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    // Test connection before saving
    const testService = new UrBackupService({
      id: 0,
      name,
      host,
      port: parseInt(port),
      fqdn: null,
      username,
      password,
      is_default: false,
      is_active: true,
      created_at: new Date(),
      updated_at: new Date(),
    });

    const connectionOk = await testService.testConnection();
    if (!connectionOk) {
      res.status(400).json({ error: 'Failed to connect to UrBackup server' });
      return;
    }

    const id = await serverModel.createServer(
      name,
      host,
      parseInt(port),
      null, // fqdn - will be added in future update
      username,
      password,
      isDefault || false
    );

    res.status(201).json({ id, message: 'Server created successfully' });
  } catch (error) {
    logger.error('Failed to create server:', error);
    res.status(500).json({ error: 'Failed to create server' });
  }
}

export async function updateServer(req: AuthRequest, res: Response): Promise<void> {
  try {
    const id = parseInt(req.params.id);
    const { name, host, port, username, password, isDefault } = req.body;

    if (!name || !host || !port || !username) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    const existing = await serverModel.getServerById(id);
    if (!existing) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Use existing password if not provided
    const finalPassword = password || existing.password;

    await serverModel.updateServer(
      id,
      name,
      host,
      parseInt(port),
      null, // fqdn - will be added in future update
      username,
      finalPassword,
      isDefault || false
    );

    res.json({ message: 'Server updated successfully' });
  } catch (error) {
    logger.error('Failed to update server:', error);
    res.status(500).json({ error: 'Failed to update server' });
  }
}

export async function deleteServer(req: AuthRequest, res: Response): Promise<void> {
  try {
    const id = parseInt(req.params.id);
    await serverModel.deleteServer(id);
    res.json({ message: 'Server deleted successfully' });
  } catch (error) {
    logger.error('Failed to delete server:', error);
    res.status(500).json({ error: 'Failed to delete server' });
  }
}

export async function testConnection(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { host, port, username, password } = req.body;

    if (!host || !port || !username || !password) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    const testService = new UrBackupService({
      id: 0,
      name: 'test',
      host,
      port: parseInt(port),
      fqdn: null,
      username,
      password,
      is_default: false,
      is_active: true,
      created_at: new Date(),
      updated_at: new Date(),
    });

    const connectionOk = await testService.testConnection();

    if (connectionOk) {
      const version = await testService.getServerVersion();
      res.json({ success: true, version });
    } else {
      res.json({ success: false, error: 'Failed to connect' });
    }
  } catch (error) {
    logger.error('Connection test failed:', error);
    res.json({ success: false, error: 'Connection test failed' });
  }
}
