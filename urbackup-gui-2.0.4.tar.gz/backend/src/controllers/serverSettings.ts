import { Request, Response } from 'express';
import { getServerById, getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';

async function getService(serverId?: string): Promise<UrBackupService | null> {
  let server;

  if (serverId) {
    server = await getServerById(parseInt(serverId));
  } else {
    server = await getDefaultServer();
  }

  if (!server) {
    return null;
  }

  return new UrBackupService(server);
}

/**
 * Get server settings - flatten nested structure to simple key-value pairs
 */
export async function getServerSettings(req: Request, res: Response) {
  try {
    const serverId = req.query.serverId as string | undefined;

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const rawSettings = await service.getSettings();

    // Flatten the nested settings structure to simple key-value pairs
    // Only include simple values that can be displayed in form fields
    const flatSettings: any = {};

    if (rawSettings && typeof rawSettings === 'object') {
      for (const [key, value] of Object.entries(rawSettings)) {
        let extractedValue: any;

        if (value && typeof value === 'object' && 'value' in value) {
          // This is a setting object with nested structure
          const settingObj = value as any;
          // Extract the actual value based on the structure
          if (settingObj.value !== undefined) {
            extractedValue = settingObj.value;
          } else if (settingObj.value_group !== undefined) {
            extractedValue = settingObj.value_group;
          }
        } else {
          // Simple value or non-standard structure
          extractedValue = value;
        }

        // Handle different value types
        if (typeof extractedValue === 'string' && extractedValue === '[object Object]') {
          // Skip malformed string representations
          logger.warn(`Skipping malformed setting ${key} with value "[object Object]"`);
          continue;
        }

        if (typeof extractedValue === 'object' && extractedValue !== null) {
          // Keep complex objects (like intervals, windows) but log them
          logger.info(`Including complex object setting ${key}`, extractedValue);
        }

        flatSettings[key] = extractedValue;
      }
    }

    logger.info('Returning flattened server settings:', {
      settingCount: Object.keys(flatSettings).length,
      internet_mode_enabled: `${flatSettings.internet_mode_enabled} (${typeof flatSettings.internet_mode_enabled})`,
      no_images: `${flatSettings.no_images} (${typeof flatSettings.no_images})`,
      sampleKeys: Object.keys(flatSettings).slice(0, 10).join(', ')
    });

    res.json(flatSettings);
  } catch (error: any) {
    logger.error('Failed to get server settings:', error);
    res.status(500).json({
      error: 'Failed to get server settings',
      message: error.message
    });
  }
}

/**
 * Update server settings
 */
export async function updateServerSettings(req: Request, res: Response) {
  try {
    const settings = req.body;
    const serverId = req.query.serverId as string | undefined;

    if (!settings || typeof settings !== 'object') {
      res.status(400).json({ error: 'Settings object is required' });
      return;
    }

    // Log what we're receiving
    logger.info('Received settings update request');

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Remove any settings fields that might be read-only or problematic
    const cleanSettings = { ...settings };
    delete cleanSettings.settings; // Remove nested settings if present

    logger.info(`Sending ${Object.keys(cleanSettings).length} settings to UrBackup API`);

    const result = await service.setSettings(cleanSettings);

    res.json({ success: true, result });
  } catch (error: any) {
    logger.error('Failed to update server settings:', error);
    res.status(500).json({
      error: 'Failed to update server settings',
      message: error.message
    });
  }
}
