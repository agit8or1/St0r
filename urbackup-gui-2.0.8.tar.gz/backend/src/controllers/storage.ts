import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import { getDefaultServer, getAllServers } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { StorageCalculator } from '../services/storageCalculator.js';
import { logger } from '../utils/logger.js';

const calculator = new StorageCalculator();

/**
 * Get total storage across all UrBackup servers
 */
export async function getTotalStorage(req: AuthRequest, res: Response): Promise<void> {
  try {
    const servers = await getAllServers();

    if (!servers || servers.length === 0) {
      res.json({ used: 0, available: 0, servers: [] });
      return;
    }

    let totalUsed = 0;
    let totalAvailable = 0;
    const serverData: any[] = [];

    for (const server of servers) {
      try {
        const service = new UrBackupService(server);
        const storage = await calculator.calculateStorageFromStatus(service);

        totalUsed += storage.used;
        totalAvailable += storage.available;

        serverData.push({
          serverId: server.id,
          serverName: server.name,
          used: storage.used,
          available: storage.available
        });
      } catch (error) {
        logger.error(`Failed to get storage for server ${server.name}:`, error);
        serverData.push({
          serverId: server.id,
          serverName: server.name,
          used: 0,
          available: 0,
          error: 'Failed to connect'
        });
      }
    }

    logger.info(`Total storage: ${totalUsed} bytes used across ${servers.length} servers`);

    res.json({
      used: totalUsed,
      available: totalAvailable,
      servers: serverData
    });
  } catch (error) {
    logger.error('Failed to get total storage:', error);
    res.status(500).json({ error: 'Failed to get storage information' });
  }
}

/**
 * Get storage for a specific server
 */
export async function getServerStorage(req: AuthRequest, res: Response): Promise<void> {
  try {
    const server = await getDefaultServer();

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const service = new UrBackupService(server);
    const storage = await calculator.calculateStorageFromStatus(service);

    res.json({
      serverId: server.id,
      serverName: server.name,
      used: storage.used,
      available: storage.available
    });
  } catch (error) {
    logger.error('Failed to get server storage:', error);
    res.status(500).json({ error: 'Failed to get storage information' });
  }
}
