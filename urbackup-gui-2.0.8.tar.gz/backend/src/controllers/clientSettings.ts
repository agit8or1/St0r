import { Request, Response } from 'express';
import { getServerById, getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';

async function getService(serverId?: string): Promise<UrBackupService | null> {
  let server;

  if (serverId) {
    server = await getServerById(parseInt(serverId));
  } else {
    server = await getDefaultServer();
  }

  if (!server) {
    return null;
  }

  return new UrBackupService(server);
}

/**
 * Get client settings
 */
export async function getClientSettings(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId) {
      res.status(400).json({ error: 'clientId is required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const settingsArray = await service.getClientSettings(clientId);

    // The UrBackup API returns an array with one object
    // Each setting has structure based on 'use' flag:
    // use: 4 -> value_client (client override)
    // use: 2 -> value (server override for this client)
    // use: 1 -> value_group (server/group default)
    const rawSettings = Array.isArray(settingsArray) && settingsArray.length > 0
      ? settingsArray[0]
      : {};

    // Helper to get effective value based on 'use' flag
    const getEffectiveValue = (setting: any) => {
      if (!setting || typeof setting !== 'object') return setting;
      const use = setting.use;
      if (use === 4) return setting.value_client !== undefined ? setting.value_client : setting.value;
      if (use === 2) return setting.value;
      return setting.value_group;
    };

    // Flatten the settings by extracting the effective value from each setting
    const settings: any = {};
    for (const [key, value] of Object.entries(rawSettings)) {
      if (value && typeof value === 'object' && 'use' in value) {
        const effectiveValue = getEffectiveValue(value);
        // Only include simple values (string, number, boolean)
        // Skip complex objects and arrays that can't be displayed in form fields
        if (effectiveValue !== null &&
            effectiveValue !== undefined &&
            typeof effectiveValue !== 'object' &&
            !Array.isArray(effectiveValue)) {
          settings[key] = effectiveValue;
        } else if (effectiveValue === null) {
          settings[key] = '';
        }
      } else if (value === null) {
        settings[key] = '';
      } else if (typeof value !== 'object' && !Array.isArray(value)) {
        // Only include simple values, skip arrays and objects
        settings[key] = value;
      }
    }

    logger.info(`Returning flattened settings for client ${clientId}:`, {
      settingCount: Object.keys(settings).length,
      default_dirs: settings.default_dirs,
      image_letters: settings.image_letters,
      sampleKeys: Object.keys(settings).slice(0, 5).join(', ')
    });

    res.json({ settings });
  } catch (error: any) {
    logger.error('Failed to get client settings:', error);
    res.status(500).json({
      error: 'Failed to get client settings',
      message: error.message
    });
  }
}

/**
 * Update client settings
 */
export async function updateClientSettings(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const settings = req.body;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId) {
      res.status(400).json({ error: 'clientId is required' });
      return;
    }

    if (!settings || typeof settings !== 'object') {
      res.status(400).json({ error: 'Settings object is required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const result = await service.setClientSettings(clientId, settings);

    res.json({ success: true, result });
  } catch (error: any) {
    logger.error('Failed to update client settings:', error);
    res.status(500).json({
      error: 'Failed to update client settings',
      message: error.message
    });
  }
}
