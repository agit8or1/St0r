import { useState } from 'react';
import {
  BookOpen,
  Download,
  Server,
  Users,
  Activity,
  Settings,
  Shield,
  Terminal,
  CheckCircle,
  AlertCircle,
  HardDrive,
  Database,
  Globe,
  Copy,
  Check
} from 'lucide-react';
import { Layout } from '../components/Layout';

export function Documentation() {
  const [copiedCommand, setCopiedCommand] = useState<string | null>(null);

  const copyToClipboard = (text: string, id: string) => {
    navigator.clipboard.writeText(text);
    setCopiedCommand(id);
    setTimeout(() => setCopiedCommand(null), 2000);
  };

  const downloadFile = async (filename: string) => {
    try {
      const token = localStorage.getItem('token');
      const response = await fetch(`/api/documentation/download/${filename}`, {
        headers: {
          'Authorization': `Bearer ${token}`
        }
      });

      if (!response.ok) {
        throw new Error('Download failed');
      }

      const blob = await response.blob();
      const url = window.URL.createObjectURL(blob);
      const a = document.createElement('a');
      a.href = url;
      a.download = filename;
      document.body.appendChild(a);
      a.click();
      window.URL.revokeObjectURL(url);
      document.body.removeChild(a);
    } catch (error) {
      console.error('Download error:', error);
      alert('Failed to download file. Please try again.');
    }
  };

  const installCommand = "curl -fsSL http://stor.agit8or.net/downloads/install.sh | sudo bash";
  const wgetCommand = "wget -qO- http://stor.agit8or.net/downloads/install.sh | sudo bash";

  return (
    <Layout>
      <div className="space-y-6">
        {/* Header */}
        <div className="flex items-center gap-4">
          <div className="p-3 bg-gradient-to-br from-blue-500 to-purple-600 rounded-xl">
            <BookOpen className="h-8 w-8 text-white" />
          </div>
          <div>
            <h1 className="text-3xl font-bold text-gray-900 dark:text-gray-100">Documentation</h1>
            <p className="text-gray-600 dark:text-gray-400">Complete guide to using St0r</p>
          </div>
        </div>

        {/* Table of Contents */}
        <div className="card">
          <h2 className="text-xl font-bold text-gray-900 dark:text-gray-100 mb-4">Table of Contents</h2>
          <div className="grid md:grid-cols-2 gap-3">
            <a href="#installation" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Download className="h-4 w-4" />
              Installation
            </a>
            <a href="#features" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <CheckCircle className="h-4 w-4" />
              Features Overview
            </a>
            <a href="#dashboard" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <HardDrive className="h-4 w-4" />
              Dashboard
            </a>
            <a href="#clients" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Users className="h-4 w-4" />
              Managing Clients
            </a>
            <a href="#activities" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Activity className="h-4 w-4" />
              Activities & Backups
            </a>
            <a href="#servers" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Server className="h-4 w-4" />
              Server Management
            </a>
            <a href="#settings" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Settings className="h-4 w-4" />
              Settings & Configuration
            </a>
            <a href="#troubleshooting" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <AlertCircle className="h-4 w-4" />
              Troubleshooting
            </a>
            <a href="#database-repair" className="flex items-center gap-2 text-blue-600 dark:text-blue-400 hover:underline">
              <Database className="h-4 w-4" />
              Database Repair Scripts
            </a>
          </div>
        </div>

        {/* Installation Section */}
        <div id="installation" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Download className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Installation</h2>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Quick Install (Recommended)</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Run this single command to download and install St0r automatically:
              </p>

              <div className="bg-gray-900 dark:bg-gray-950 rounded-lg p-4 mb-3">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-400">Using curl:</span>
                  <button
                    onClick={() => copyToClipboard(installCommand, 'curl')}
                    className="p-1 hover:bg-gray-800 rounded"
                  >
                    {copiedCommand === 'curl' ? (
                      <Check className="h-4 w-4 text-green-400" />
                    ) : (
                      <Copy className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
                <code className="text-sm text-green-400 font-mono break-all">
                  {installCommand}
                </code>
              </div>

              <div className="bg-gray-900 dark:bg-gray-950 rounded-lg p-4">
                <div className="flex items-center justify-between mb-2">
                  <span className="text-xs text-gray-400">Or using wget:</span>
                  <button
                    onClick={() => copyToClipboard(wgetCommand, 'wget')}
                    className="p-1 hover:bg-gray-800 rounded"
                  >
                    {copiedCommand === 'wget' ? (
                      <Check className="h-4 w-4 text-green-400" />
                    ) : (
                      <Copy className="h-4 w-4 text-gray-400" />
                    )}
                  </button>
                </div>
                <code className="text-sm text-green-400 font-mono break-all">
                  {wgetCommand}
                </code>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <Shield className="h-5 w-5 text-blue-600 dark:text-blue-400 mt-0.5 flex-shrink-0" />
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">Upgrade Detection</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    The installer automatically detects existing installations and will safely upgrade your system while preserving all data and settings.
                  </p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">What Gets Installed</h3>
              <ul className="space-y-2">
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-400">Node.js 20.x (if not already installed)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-400">MariaDB database server</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-400">Nginx web server</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-400">St0r application (frontend & backend)</span>
                </li>
                <li className="flex items-start gap-2">
                  <CheckCircle className="h-5 w-5 text-green-600 dark:text-green-400 mt-0.5 flex-shrink-0" />
                  <span className="text-gray-600 dark:text-gray-400">systemd service for automatic startup</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Default Credentials</h3>
              <div className="bg-gray-50 dark:bg-gray-800 rounded-lg p-4">
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">After installation, login with:</p>
                <div className="font-mono text-sm">
                  <p className="text-gray-900 dark:text-gray-100">Username: <span className="text-blue-600 dark:text-blue-400">admin</span></p>
                  <p className="text-gray-900 dark:text-gray-100">Password: <span className="text-blue-600 dark:text-blue-400">admin</span></p>
                </div>
                <p className="text-xs text-orange-600 dark:text-orange-400 mt-2">⚠️ Change the default password after first login!</p>
              </div>
            </div>
          </div>
        </div>

        {/* Features Section */}
        <div id="features" className="card">
          <div className="flex items-center gap-3 mb-4">
            <CheckCircle className="h-6 w-6 text-green-600 dark:text-green-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Features Overview</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div className="border dark:border-gray-700 rounded-lg p-4">
              <HardDrive className="h-8 w-8 text-blue-600 dark:text-blue-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Multi-Server Management</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Manage multiple UrBackup servers from a single interface with aggregated statistics and unified monitoring.
              </p>
            </div>

            <div className="border dark:border-gray-700 rounded-lg p-4">
              <Activity className="h-8 w-8 text-purple-600 dark:text-purple-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Real-Time Activities</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Monitor backup progress in real-time with live speed calculations, ETA estimates, and beautiful progress indicators.
              </p>
            </div>

            <div className="border dark:border-gray-700 rounded-lg p-4">
              <Database className="h-8 w-8 text-green-600 dark:text-green-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Storage Analytics</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Track storage usage across all servers and clients with detailed breakdowns of file and image backups.
              </p>
            </div>

            <div className="border dark:border-gray-700 rounded-lg p-4">
              <Users className="h-8 w-8 text-orange-600 dark:text-orange-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Client Management</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                View all clients, their status, backup history, and trigger manual backups (full or incremental, file or image).
              </p>
            </div>

            <div className="border dark:border-gray-700 rounded-lg p-4">
              <Settings className="h-8 w-8 text-gray-600 dark:text-gray-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Advanced Settings</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Configure server and client settings including backup intervals, windows, retention policies, and more.
              </p>
            </div>

            <div className="border dark:border-gray-700 rounded-lg p-4">
              <Globe className="h-8 w-8 text-indigo-600 dark:text-indigo-400 mb-3" />
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Modern UI</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400">
                Beautiful, responsive interface with dark mode support, gradient animations, and an intuitive user experience.
              </p>
            </div>
          </div>
        </div>

        {/* Dashboard Section */}
        <div id="dashboard" className="card">
          <div className="flex items-center gap-3 mb-4">
            <HardDrive className="h-6 w-6 text-blue-600 dark:text-blue-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Dashboard</h2>
          </div>

          <div className="space-y-4">
            <p className="text-gray-600 dark:text-gray-400">
              The Dashboard provides an at-a-glance view of your entire backup infrastructure:
            </p>

            <div className="space-y-3">
              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-blue-600 dark:text-blue-400">1</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">Key Metrics</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    View total clients, active backups, storage usage, and success rate at the top of the dashboard.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-blue-600 dark:text-blue-400">2</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">Client Status Distribution</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Interactive pie chart showing online, offline, failed, and OK clients. Click segments to filter.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-blue-600 dark:text-blue-400">3</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">Recent Activities</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    See the latest backup jobs with progress bars, client names, and backup types.
                  </p>
                </div>
              </div>

              <div className="flex items-start gap-3">
                <div className="w-8 h-8 rounded-full bg-blue-100 dark:bg-blue-900 flex items-center justify-center flex-shrink-0">
                  <span className="text-sm font-bold text-blue-600 dark:text-blue-400">4</span>
                </div>
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100">Storage Trends</h4>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    Area chart showing storage usage growth over time with file and image backup breakdown.
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Clients Section */}
        <div id="clients" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Users className="h-6 w-6 text-orange-600 dark:text-orange-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Managing Clients</h2>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Client List</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                The Clients page shows all backup clients across all configured servers with:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 dark:text-blue-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Status indicators (Online/Offline)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 dark:text-blue-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Last backup timestamps</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 dark:text-blue-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Storage usage per client</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-blue-600 dark:text-blue-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Backup success/failure status</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Starting Manual Backups</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Click on any client to view details and start backups:
              </p>
              <div className="grid sm:grid-cols-2 gap-3">
                <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-1 text-sm">Full File Backup</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Complete backup of all configured files and folders</p>
                </div>
                <div className="bg-green-50 dark:bg-green-900/20 border border-green-200 dark:border-green-800 rounded-lg p-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-1 text-sm">Incremental File Backup</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Only backs up files changed since last backup</p>
                </div>
                <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-1 text-sm">Full Image Backup</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Complete disk/partition image backup</p>
                </div>
                <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-3">
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-1 text-sm">Incremental Image Backup</h4>
                  <p className="text-xs text-gray-600 dark:text-gray-400">Only changed blocks since last image backup</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Client Details</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Click any client card to view detailed information including backup history, settings, and available actions.
              </p>
            </div>
          </div>
        </div>

        {/* Activities Section */}
        <div id="activities" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Activity className="h-6 w-6 text-purple-600 dark:text-purple-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Activities & Backups</h2>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Real-Time Monitoring</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                The Activities page provides live monitoring of all backup operations:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 dark:text-purple-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Live progress bars with shimmer animations</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 dark:text-purple-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Real-time speed calculations (MB/s)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 dark:text-purple-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Estimated time remaining (ETA)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 dark:text-purple-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Data transferred vs. total size</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-purple-600 dark:text-purple-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Paused backup detection</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Auto-Refresh</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Toggle the auto-refresh button to enable automatic updates every 3 seconds. The spinning icon indicates active refresh.
              </p>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Filtering</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Use the filter buttons to view:
              </p>
              <div className="flex flex-wrap gap-2">
                <span className="px-3 py-1 bg-blue-100 dark:bg-blue-900 text-blue-700 dark:text-blue-300 rounded-full text-sm">All Activities</span>
                <span className="px-3 py-1 bg-green-100 dark:bg-green-900 text-green-700 dark:text-green-300 rounded-full text-sm">Running Only</span>
                <span className="px-3 py-1 bg-gray-100 dark:bg-gray-800 text-gray-700 dark:text-gray-300 rounded-full text-sm">Completed</span>
                <span className="px-3 py-1 bg-purple-100 dark:bg-purple-900 text-purple-700 dark:text-purple-300 rounded-full text-sm">Files</span>
                <span className="px-3 py-1 bg-orange-100 dark:bg-orange-900 text-orange-700 dark:text-orange-300 rounded-full text-sm">Images</span>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Completed Activities</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Scroll down to see recently completed backups. Failed backups are grouped separately and can be expanded/collapsed for a cleaner view.
              </p>
            </div>
          </div>
        </div>

        {/* Servers Section */}
        <div id="servers" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Server className="h-6 w-6 text-green-600 dark:text-green-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Server Management</h2>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Adding UrBackup Servers</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Click "Add Server" to connect a new UrBackup server instance. Provide:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Server name (display name)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Hostname or IP address</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Port (default: 55414)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Username and password for UrBackup web interface</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Server Statistics</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Each server card displays:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Number of connected clients</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Total storage used by backups</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-green-600 dark:text-green-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Connection status</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Editing & Removing Servers</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Use the edit and delete buttons on each server card to modify connection settings or remove servers from St0r.
              </p>
            </div>
          </div>
        </div>

        {/* Settings Section */}
        <div id="settings" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Settings className="h-6 w-6 text-gray-600 dark:text-gray-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Settings & Configuration</h2>
          </div>

          <div className="space-y-4">
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Server Settings</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Access server-level configuration from the Settings page:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Backup retention policies</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Default backup intervals</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Global backup windows</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Email notifications</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Client-Specific Settings</h3>
              <p className="text-gray-600 dark:text-gray-400 mb-3">
                Click on a client and navigate to its settings tab to configure:
              </p>
              <ul className="space-y-2 ml-4">
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Backup intervals (full and incremental)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Backup windows (time restrictions)</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Retention counts and durations</span>
                </li>
                <li className="flex items-start gap-2">
                  <span className="text-gray-600 dark:text-gray-400">•</span>
                  <span className="text-gray-600 dark:text-gray-400">Excluded paths and file types</span>
                </li>
              </ul>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">User Management</h3>
              <p className="text-gray-600 dark:text-gray-400">
                Create additional users, assign permissions, and manage passwords from the Users page.
              </p>
            </div>
          </div>
        </div>

        {/* Troubleshooting Section */}
        <div id="troubleshooting" className="card">
          <div className="flex items-center gap-3 mb-4">
            <AlertCircle className="h-6 w-6 text-red-600 dark:text-red-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Troubleshooting</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-yellow-50 dark:bg-yellow-900/20 border border-yellow-200 dark:border-yellow-800 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Server Connection Issues</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">If a server shows as disconnected:</p>
              <ul className="space-y-1 ml-4 text-sm text-gray-600 dark:text-gray-400">
                <li>1. Verify the UrBackup server is running</li>
                <li>2. Check firewall rules allow port 55414</li>
                <li>3. Confirm credentials are correct</li>
                <li>4. Test connectivity: <code className="bg-gray-900 text-green-400 px-2 py-0.5 rounded">curl http://server:55414</code></li>
              </ul>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Backup Not Starting</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">If manual backups don't start:</p>
              <ul className="space-y-1 ml-4 text-sm text-gray-600 dark:text-gray-400">
                <li>1. Check if client is online</li>
                <li>2. Verify backup windows allow backups now</li>
                <li>3. Check UrBackup server logs for errors</li>
                <li>4. Ensure client has UrBackup agent installed</li>
              </ul>
            </div>

            <div className="bg-red-50 dark:bg-red-900/20 border border-red-200 dark:border-red-800 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Storage Not Showing</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">If storage statistics show 0:</p>
              <ul className="space-y-1 ml-4 text-sm text-gray-600 dark:text-gray-400">
                <li>1. Wait a few minutes for data collection</li>
                <li>2. Check server logs: <code className="bg-gray-900 text-green-400 px-2 py-0.5 rounded">sudo journalctl -u urbackup-gui -n 50</code></li>
                <li>3. Verify UrBackup server API is accessible</li>
                <li>4. Check user permissions on UrBackup server</li>
              </ul>
            </div>

            <div className="bg-purple-50 dark:bg-purple-900/20 border border-purple-200 dark:border-purple-800 rounded-lg p-4">
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Service Management</h3>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-2">Useful commands:</p>
              <div className="space-y-2">
                <div className="bg-gray-900 dark:bg-gray-950 rounded p-2">
                  <code className="text-xs text-green-400">sudo systemctl status urbackup-gui</code>
                  <p className="text-xs text-gray-400 mt-1">Check service status</p>
                </div>
                <div className="bg-gray-900 dark:bg-gray-950 rounded p-2">
                  <code className="text-xs text-green-400">sudo systemctl restart urbackup-gui</code>
                  <p className="text-xs text-gray-400 mt-1">Restart the backend service</p>
                </div>
                <div className="bg-gray-900 dark:bg-gray-950 rounded p-2">
                  <code className="text-xs text-green-400">sudo systemctl restart nginx</code>
                  <p className="text-xs text-gray-400 mt-1">Restart the web server</p>
                </div>
              </div>
            </div>

            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-2">Getting Help</h3>
              <p className="text-gray-600 dark:text-gray-400">
                For additional support, check the application logs or contact your system administrator.
              </p>
            </div>
          </div>
        </div>

        {/* Database Repair Scripts Section */}
        <div id="database-repair" className="card">
          <div className="flex items-center gap-3 mb-4">
            <Database className="h-6 w-6 text-red-600 dark:text-red-400" />
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Database Repair Scripts</h2>
          </div>

          <div className="space-y-4">
            <div className="bg-orange-50 dark:bg-orange-900/20 border border-orange-200 dark:border-orange-800 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <AlertCircle className="h-5 w-5 text-orange-600 dark:text-orange-400 flex-shrink-0 mt-0.5" />
                <div>
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">
                    Fixing Corrupted UrBackup Settings
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400">
                    If your UrBackup server shows corrupted values like "[object Object]", "NaN", or "undefined" in settings,
                    these scripts will fix them by directly editing the UrBackup database. Run these on your UrBackup server (not on the St0r GUI server).
                  </p>
                </div>
              </div>
            </div>

            <div className="grid md:grid-cols-2 gap-4">
              {/* Windows Script */}
              <div className="border-2 border-blue-200 dark:border-blue-800 rounded-lg p-4 hover:border-blue-400 dark:hover:border-blue-600 transition-colors">
                <div className="flex items-start gap-3 mb-3">
                  <div className="p-2 bg-blue-100 dark:bg-blue-900 rounded-lg">
                    <Terminal className="h-5 w-5 text-blue-600 dark:text-blue-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                      Windows PowerShell Script
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">For Windows UrBackup Servers</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  Automated PowerShell script that finds the database, creates a backup, stops the service, fixes corrupted settings, and restarts.
                </p>
                <button
                  onClick={() => downloadFile('Fix-UrBackupSettings.ps1')}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-blue-600 hover:bg-blue-700 text-white rounded-lg transition-colors text-sm w-full justify-center"
                >
                  <Download className="h-4 w-4" />
                  Download PowerShell Script
                </button>
              </div>

              {/* Linux Script */}
              <div className="border-2 border-green-200 dark:border-green-800 rounded-lg p-4 hover:border-green-400 dark:hover:border-green-600 transition-colors">
                <div className="flex items-start gap-3 mb-3">
                  <div className="p-2 bg-green-100 dark:bg-green-900 rounded-lg">
                    <Terminal className="h-5 w-5 text-green-600 dark:text-green-400" />
                  </div>
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                      Linux Bash Script
                    </h3>
                    <p className="text-xs text-gray-500 dark:text-gray-400">For Linux UrBackup Servers</p>
                  </div>
                </div>
                <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                  Bash script for Linux servers that automatically locates the database, creates a backup, and fixes all corrupted settings.
                </p>
                <button
                  onClick={() => downloadFile('Fix-UrBackupSettings-Linux.sh')}
                  className="inline-flex items-center gap-2 px-4 py-2 bg-green-600 hover:bg-green-700 text-white rounded-lg transition-colors text-sm w-full justify-center"
                >
                  <Download className="h-4 w-4" />
                  Download Bash Script
                </button>
              </div>
            </div>

            {/* Diagnostic Script - NEW */}
            <div className="border-2 border-yellow-200 dark:border-yellow-800 rounded-lg p-4 hover:border-yellow-400 dark:hover:border-yellow-600 transition-colors">
              <div className="flex items-start gap-3 mb-3">
                <div className="p-2 bg-yellow-100 dark:bg-yellow-900 rounded-lg">
                  <AlertCircle className="h-5 w-5 text-yellow-600 dark:text-yellow-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                    Database Diagnostic Script (Windows)
                  </h3>
                  <p className="text-xs text-yellow-600 dark:text-yellow-400 font-medium">⚠️ Run this FIRST to identify issues</p>
                </div>
              </div>
              <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                This script will scan your UrBackup database and show you exactly what's corrupted: bad settings, invalid client auth keys, and service status. Run this before using the fix script to see what needs repair.
              </p>
              <button
                onClick={() => downloadFile('Diagnose-UrBackup-Database.ps1')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-yellow-600 hover:bg-yellow-700 text-white rounded-lg transition-colors text-sm w-full justify-center"
              >
                <Download className="h-4 w-4" />
                Download Diagnostic Script
              </button>
            </div>

            {/* CLIENT AUTHENTICATION FIX - CRITICAL */}
            <div className="border-2 border-red-200 dark:border-red-800 rounded-lg p-4 hover:border-red-400 dark:hover:border-red-600 transition-colors bg-red-50 dark:bg-red-950">
              <div className="flex items-start gap-3 mb-3">
                <div className="p-2 bg-red-100 dark:bg-red-900 rounded-lg">
                  <Shield className="h-5 w-5 text-red-600 dark:text-red-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                    Client Authentication Fix (Windows)
                  </h3>
                  <p className="text-xs text-red-600 dark:text-red-400 font-bold">🚨 FIXES: "authentication failure: unknown client" errors</p>
                </div>
              </div>
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                <strong>Use this if clients can't connect to your UrBackup server.</strong> This script automatically:
                • Creates a backup of your database
                • Fixes corrupted settings
                • Regenerates client authentication keys
                • Cleans up broken entries
                • Restarts services
              </p>
              <button
                onClick={() => downloadFile('Fix-Client-Authentication.ps1')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-red-600 hover:bg-red-700 text-white rounded-lg transition-colors text-sm w-full justify-center font-semibold"
              >
                <Download className="h-4 w-4" />
                Download Authentication Fix Script
              </button>
            </div>

            {/* SERVER CONFIGURATION BACKUP */}
            <div className="border-2 border-purple-200 dark:border-purple-800 rounded-lg p-4 hover:border-purple-400 dark:hover:border-purple-600 transition-colors bg-purple-50 dark:bg-purple-950">
              <div className="flex items-start gap-3 mb-3">
                <div className="p-2 bg-purple-100 dark:bg-purple-900 rounded-lg">
                  <Database className="h-5 w-5 text-purple-600 dark:text-purple-400" />
                </div>
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                    Server Configuration Backup (Windows)
                  </h3>
                  <p className="text-xs text-purple-600 dark:text-purple-400 font-medium">💾 Backup server settings, database, and keys</p>
                </div>
              </div>
              <p className="text-sm text-gray-700 dark:text-gray-300 mb-3">
                <strong>Backs up your UrBackup server configuration:</strong>
                • Database files and settings
                • Server identity keys
                • Session keys
                • Configuration files
                • Recent log files
                Creates a compressed ZIP file on your desktop.
              </p>
              <button
                onClick={() => downloadFile('Backup-UrBackup-Config.ps1')}
                className="inline-flex items-center gap-2 px-4 py-2 bg-purple-600 hover:bg-purple-700 text-white rounded-lg transition-colors text-sm w-full justify-center font-semibold"
              >
                <Download className="h-4 w-4" />
                Download Config Backup Script
              </button>
            </div>

            {/* Instructions */}
            <div className="border border-gray-200 dark:border-gray-700 rounded-lg p-4">
              <div className="flex items-start gap-3 mb-3">
                <BookOpen className="h-5 w-5 text-gray-600 dark:text-gray-400 mt-0.5 flex-shrink-0" />
                <div className="flex-1">
                  <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-1">
                    Instructions & Troubleshooting
                  </h3>
                  <p className="text-sm text-gray-600 dark:text-gray-400 mb-3">
                    Detailed step-by-step instructions, manual database editing guide, and troubleshooting tips.
                  </p>
                  <a
                    href="http://localhost:3000/api/documentation/download/FINAL-FIX-INSTRUCTIONS.txt"
                    download
                    className="inline-flex items-center gap-2 px-3 py-2 bg-gray-600 hover:bg-gray-700 text-white rounded-lg transition-colors text-sm"
                  >
                    <Download className="h-4 w-4" />
                    Download Instructions (TXT)
                  </a>
                </div>
              </div>
            </div>

            {/* Usage Steps */}
            <div>
              <h3 className="text-lg font-semibold text-gray-900 dark:text-gray-100 mb-3">How to Use</h3>

              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2 flex items-center gap-2">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-blue-100 dark:bg-blue-900 text-blue-600 dark:text-blue-400 text-sm">W</span>
                    For Windows Servers:
                  </h4>
                  <ol className="list-decimal list-inside space-y-1 ml-8 text-sm text-gray-600 dark:text-gray-400">
                    <li>Download the PowerShell script (.ps1 file)</li>
                    <li>Transfer it to your Windows UrBackup server</li>
                    <li>Right-click the file → "Run with PowerShell as Administrator"</li>
                    <li>Follow the on-screen prompts</li>
                    <li>The script will automatically backup, fix, and restart your server</li>
                  </ol>
                </div>

                <div>
                  <h4 className="font-semibold text-gray-900 dark:text-gray-100 mb-2 flex items-center gap-2">
                    <span className="flex items-center justify-center w-6 h-6 rounded-full bg-green-100 dark:bg-green-900 text-green-600 dark:text-green-400 text-sm">L</span>
                    For Linux Servers:
                  </h4>
                  <ol className="list-decimal list-inside space-y-1 ml-8 text-sm text-gray-600 dark:text-gray-400">
                    <li>Download the Bash script (.sh file)</li>
                    <li>Transfer it to your Linux UrBackup server</li>
                    <li>Make it executable: <code className="bg-gray-900 text-green-400 px-2 py-0.5 rounded text-xs">chmod +x Fix-UrBackupSettings-Linux.sh</code></li>
                    <li>Run as root: <code className="bg-gray-900 text-green-400 px-2 py-0.5 rounded text-xs">sudo ./Fix-UrBackupSettings-Linux.sh</code></li>
                    <li>Follow the prompts to complete the fix</li>
                  </ol>
                </div>
              </div>
            </div>

            <div className="bg-blue-50 dark:bg-blue-900/20 border border-blue-200 dark:border-blue-800 rounded-lg p-4">
              <div className="flex items-start gap-3">
                <CheckCircle className="h-5 w-5 text-blue-600 dark:text-blue-400 flex-shrink-0 mt-0.5" />
                <div className="text-sm">
                  <p className="font-semibold text-gray-900 dark:text-gray-100 mb-1">Important Notes:</p>
                  <ul className="space-y-1 text-gray-600 dark:text-gray-400 ml-4">
                    <li>• These scripts must run on the UrBackup server itself (not on St0r GUI server)</li>
                    <li>• Scripts automatically create a database backup before making changes</li>
                    <li>• The UrBackup service will be temporarily stopped during the fix</li>
                    <li>• All corrupted "[object Object]", "NaN", and "undefined" values will be cleared or reset to defaults</li>
                  </ul>
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Additional Resources */}
        <div className="card bg-gradient-to-br from-blue-50 to-purple-50 dark:from-blue-900/20 dark:to-purple-900/20 border-2 border-blue-200 dark:border-blue-800">
          <div className="flex items-center gap-3 mb-4">
            <div className="p-2 bg-blue-600 rounded-lg">
              <Terminal className="h-6 w-6 text-white" />
            </div>
            <h2 className="text-2xl font-bold text-gray-900 dark:text-gray-100">Quick Reference</h2>
          </div>

          <div className="grid md:grid-cols-2 gap-4">
            <div>
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Installation Files</h3>
              <div className="space-y-1 text-sm">
                <p className="text-gray-600 dark:text-gray-400">
                  <a href="http://stor.agit8or.net/downloads/install.sh" className="text-blue-600 dark:text-blue-400 hover:underline">
                    http://stor.agit8or.net/downloads/install.sh
                  </a>
                </p>
                <p className="text-gray-600 dark:text-gray-400">
                  <a href="http://stor.agit8or.net/downloads/urbackup-gui.tar.gz" className="text-blue-600 dark:text-blue-400 hover:underline">
                    http://stor.agit8or.net/downloads/urbackup-gui.tar.gz
                  </a>
                </p>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Default Ports</h3>
              <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                <p>St0r Web Interface: <span className="font-mono text-blue-600 dark:text-blue-400">80</span></p>
                <p>St0r Backend API: <span className="font-mono text-blue-600 dark:text-blue-400">3000</span></p>
                <p>UrBackup Server: <span className="font-mono text-blue-600 dark:text-blue-400">55414</span></p>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Service Names</h3>
              <div className="space-y-1 text-sm text-gray-600 dark:text-gray-400">
                <p>Backend: <span className="font-mono text-blue-600 dark:text-blue-400">urbackup-gui</span></p>
                <p>Web Server: <span className="font-mono text-blue-600 dark:text-blue-400">nginx</span></p>
                <p>Database: <span className="font-mono text-blue-600 dark:text-blue-400">mariadb</span></p>
              </div>
            </div>

            <div>
              <h3 className="font-semibold text-gray-900 dark:text-gray-100 mb-2">Installation Directory</h3>
              <div className="text-sm text-gray-600 dark:text-gray-400">
                <p className="font-mono text-blue-600 dark:text-blue-400">/opt/urbackup-gui</p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </Layout>
  );
}
