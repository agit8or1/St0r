import { Request, Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import { logger } from '../utils/logger.js';
import { getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import os from 'os';
import axios from 'axios';
import crypto from 'crypto';

/**
 * Get the server's hostname/FQDN or IP address
 */
function getServerHost(): string {
  // Prefer configured host from environment
  if (process.env.URBACKUP_SERVER_HOST) {
    return process.env.URBACKUP_SERVER_HOST;
  }

  // Fall back to auto-detected IP
  const interfaces = os.networkInterfaces();
  for (const name of Object.keys(interfaces)) {
    const iface = interfaces[name];
    if (!iface) continue;

    for (const addr of iface) {
      if (addr.family === 'IPv4' && !addr.internal) {
        return addr.address;
      }
    }
  }
  return 'localhost';
}

/**
 * Hash password using PBKDF2 (same as UrBackup server)
 */
async function hashPassword(salt: string, rounds: number, password: string): Promise<string> {
  return new Promise((resolve, reject) => {
    crypto.pbkdf2(password, Buffer.from(salt, 'hex'), rounds, 32, 'sha256', (err, derivedKey) => {
      if (err) reject(err);
      else resolve(derivedKey.toString('hex'));
    });
  });
}

/**
 * Download Windows client installer from official UrBackup website
 */
export async function getWindowsInstaller(req: AuthRequest, res: Response): Promise<void> {
  try {
    const authKey = req.query.authkey as string | undefined;

    // If authkey is provided, generate a config script instead of direct download
    if (authKey) {
      const serverHost = getServerHost();
      const serverPort = process.env.URBACKUP_SERVER_PORT || '55414';

      // Generate PowerShell configuration script
      const script = `# UrBackup Client Auto-Configuration Script
# Server: ${serverHost}:${serverPort}

Write-Host "================================================"
Write-Host "UrBackup Client Auto-Installer & Configurator"
Write-Host "Server: ${serverHost}:${serverPort}"
Write-Host "================================================"
Write-Host ""

# Check for admin rights
if (-NOT ([Security.Principal.WindowsPrincipal][Security.Principal.WindowsIdentity]::GetCurrent()).IsInRole([Security.Principal.WindowsBuiltInRole] "Administrator")) {
    Write-Host "ERROR: Please run this script as Administrator"
    pause
    exit 1
}

# Download installer
Write-Host "Downloading UrBackup Client installer..."
$installerUrl = "https://hndl.urbackup.org/Client/2.5.26/UrBackup%20Client%202.5.26.exe"
$installerPath = "$env:TEMP\\UrBackup-Client-2.5.26.exe"

try {
    Invoke-WebRequest -Uri $installerUrl -OutFile $installerPath -UseBasicParsing
} catch {
    Write-Host "ERROR: Failed to download installer: $_"
    pause
    exit 1
}

# Run installer silently
Write-Host "Installing UrBackup Client..."
Start-Process -FilePath $installerPath -ArgumentList "/S" -Wait -NoNewWindow

# Wait for installation to complete
Start-Sleep -Seconds 5

# Configure authentication
Write-Host "Configuring authentication key..."
$configDir = "$env:ProgramFiles\\UrBackup"
$dataDir = "$configDir\\data"
$authFile = "$dataDir\\server_idents.txt"

# Create data directory
New-Item -ItemType Directory -Path $dataDir -Force -ErrorAction SilentlyContinue | Out-Null

# Create auth file with the provided key
$authContent = "${authKey}#${serverHost}"
Set-Content -Path $authFile -Value $authContent -Force -Encoding ASCII

# Configure server connection using urbackupclientctl
$urbackupCtl = "$configDir\\urbackupclientctl.exe"
if (Test-Path $urbackupCtl) {
    Write-Host "Configuring via urbackupclientctl..."
    & $urbackupCtl set-settings -k internet_mode_enabled -v true
    & $urbackupCtl set-settings -k internet_server -v "${serverHost}"
    & $urbackupCtl set-settings -k internet_server_port -v ${serverPort}
    & $urbackupCtl set-settings -k internet_authkey -v "${authKey}"
    Write-Host "✓ Settings configured via urbackupclientctl"
} else {
    Write-Host "urbackupclientctl not found, using manual configuration..."
    # Fallback: Manual settings file
    $settingsFile = "$dataDir\\settings.cfg"
    $settings = @"
internet_mode_enabled=true
internet_server=${serverHost}
internet_server_port=${serverPort}
internet_authkey=${authKey}
internet_connect_always=true
"@
    Set-Content -Path $settingsFile -Value $settings -Force -Encoding ASCII
}

# Restart UrBackup service
Write-Host "Restarting UrBackup Client service..."
try {
    Restart-Service -Name "UrBackupClientBackend" -Force -ErrorAction SilentlyContinue
} catch {
    Write-Host "Warning: Could not restart service automatically. Please restart it manually."
}

# Clean up installer
Remove-Item -Path $installerPath -Force -ErrorAction SilentlyContinue

Write-Host ""
Write-Host "================================================"
Write-Host "Installation and configuration complete!"
Write-Host "Server: ${serverHost}:${serverPort}"
Write-Host "Authentication: Configured"
Write-Host "================================================"
Write-Host ""
Write-Host "The client will automatically connect to the backup server."
pause
`;

      res.setHeader('Content-Type', 'text/plain; charset=utf-8');
      res.setHeader('Content-Disposition', 'attachment; filename="install-urbackup-client.ps1"');
      res.send(script);
      return;
    }

    // No authkey - download regular installer
    const downloadUrl = 'https://hndl.urbackup.org/Client/2.5.26/UrBackup%20Client%202.5.26.exe';

    logger.info(`Downloading Windows client from: ${downloadUrl}`);

    // Stream the file directly to the client
    const fileResponse = await axios.get<any>(downloadUrl, {
      responseType: 'stream',
      timeout: 120000 // 2 minute timeout for large files
    });

    // Set appropriate headers
    res.setHeader('Content-Type', 'application/octet-stream');
    res.setHeader('Content-Disposition', 'attachment; filename="UrBackup-Client-2.5.26.exe"');

    if (fileResponse.headers['content-length']) {
      res.setHeader('Content-Length', fileResponse.headers['content-length']);
    }

    logger.info('Windows client download started successfully');

    // Pipe the file stream to response
    (fileResponse.data as any).pipe(res);

  } catch (error: any) {
    logger.error('Failed to download Windows installer:', error);

    // If already streaming, can't send JSON error
    if (res.headersSent) {
      res.end();
    } else {
      res.status(500).json({
        error: 'Failed to download Windows client installer',
        message: error.message
      });
    }
  }
}

/**
 * Generate Linux bash installer script
 */
export async function getLinuxInstaller(req: AuthRequest, res: Response): Promise<void> {
  try {
    const serverHost = getServerHost();
    const serverPort = process.env.URBACKUP_SERVER_PORT || '55414';
    const authKey = req.query.authkey as string | undefined;

    const authConfig = authKey ? `
# Configure authentication key
echo "Configuring authentication key..."
AUTH_FILE="/usr/local/var/urbackup/data/server_idents.txt"
mkdir -p "$(dirname "$AUTH_FILE")"
echo "${authKey}#${serverHost}" > "$AUTH_FILE"
` : '';

    const authConfigLine = authKey ? `internet_authkey=${authKey}` : '';

    const script = `#!/bin/bash
# UrBackup Client Auto-Install Script
# Server: ${serverHost}:${serverPort}
${authKey ? '# Authentication: Pre-configured' : ''}

set -e

echo "================================================"
echo "UrBackup Client Auto-Installer"
echo "Server: ${serverHost}:${serverPort}"
${authKey ? 'echo "Authentication: Pre-configured"' : ''}
echo "================================================"
echo ""

# Check if running as root
if [ "$EUID" -ne 0 ]; then
    echo "ERROR: Please run as root (use sudo)"
    exit 1
fi

# Download and install UrBackup Client
echo "Downloading UrBackup Client installer..."
INSTALLER_URL="https://hndl.urbackup.org/Client/2.5.26/UrBackup%20Client%20Linux%202.5.26.sh"
INSTALLER_PATH="/tmp/urbackup-install.sh"

if command -v wget &> /dev/null; then
    wget -O "$INSTALLER_PATH" "$INSTALLER_URL"
elif command -v curl &> /dev/null; then
    curl -L -o "$INSTALLER_PATH" "$INSTALLER_URL"
else
    echo "ERROR: Neither wget nor curl found. Please install one of them."
    exit 1
fi

echo "Installing UrBackup Client..."
chmod +x "$INSTALLER_PATH"
"$INSTALLER_PATH" --non-interactive

# Wait for installation to complete
sleep 3
${authConfig}
# Configure server connection
echo "Configuring server connection..."

# Configure via urbackupclientctl for proper settings
if command -v urbackupclientctl &> /dev/null; then
    echo "Configuring UrBackup client settings..."
    urbackupclientctl set-settings -k internet_mode_enabled -v true
    urbackupclientctl set-settings -k internet_server -v "${serverHost}"
    urbackupclientctl set-settings -k internet_server_port -v "${serverPort}"
    ${authKey ? `urbackupclientctl set-settings -k internet_authkey -v "${authKey}"` : ''}
    echo "✓ Settings configured via urbackupclientctl"
else
    # Fallback: Manual configuration file
    echo "urbackupclientctl not found, using manual configuration..."
    CONFIG_DIR="/usr/local/var/urbackup"
    CONFIG_FILE="$CONFIG_DIR/data/settings.cfg"

    mkdir -p "$CONFIG_DIR/data"

    cat > "$CONFIG_FILE" << EOF
internet_mode_enabled=true
internet_server=${serverHost}
internet_server_port=${serverPort}
${authConfigLine}
EOF

    # Also try /etc/urbackup location
    mkdir -p /etc/urbackup
    cp "$CONFIG_FILE" /etc/urbackup/urbackup.conf 2>/dev/null || true
fi

# Restart UrBackup service
echo "Restarting UrBackup Client service..."
if command -v systemctl &> /dev/null; then
    systemctl restart urbackupclientbackend || true
    systemctl enable urbackupclientbackend || true
elif command -v service &> /dev/null; then
    service urbackupclientbackend restart || true
fi

# Clean up
rm -f "$INSTALLER_PATH"

echo ""
echo "================================================"
echo "Installation complete!"
echo "UrBackup Client configured for: ${serverHost}:${serverPort}"
${authKey ? 'echo "Authentication: Configured with provided key"' : ''}
echo "================================================"
echo ""
echo "The client will automatically connect to the backup server."
echo "You can check the status with: urbackupclientctl status"
`;

    res.setHeader('Content-Type', 'text/plain; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="install-urbackup-client.sh"');
    res.send(script);
  } catch (error) {
    logger.error('Failed to generate Linux installer:', error);
    res.status(500).json({ error: 'Failed to generate installer script' });
  }
}

/**
 * Get server connection info (for manual configuration)
 */
export async function getServerInfo(req: AuthRequest, res: Response): Promise<void> {
  try {
    const serverHost = getServerHost();
    const serverPort = process.env.URBACKUP_SERVER_PORT || '55414';

    res.json({
      serverIP: serverHost,  // Keep property name for backwards compatibility
      serverHost,
      serverPort,
      serverUrl: `${serverHost}:${serverPort}`
    });
  } catch (error) {
    logger.error('Failed to get server info:', error);
    res.status(500).json({ error: 'Failed to get server information' });
  }
}
