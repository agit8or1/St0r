import { Request, Response } from 'express';
import { getServerById, getDefaultServer } from '../models/server.js';
import { UrBackupService } from '../services/urbackup.js';
import { logger } from '../utils/logger.js';

async function getService(serverId?: string): Promise<UrBackupService | null> {
  let server;

  if (serverId) {
    server = await getServerById(parseInt(serverId));
  } else {
    server = await getDefaultServer();
  }

  if (!server) {
    return null;
  }

  return new UrBackupService(server);
}

/**
 * Browse client's live filesystem (have client scan and report structure)
 */
export async function browseClientRoot(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId) {
      res.status(400).json({ error: 'clientId is required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    logger.info(`Requesting live filesystem scan from client ${clientId}`);

    // Request live filesystem from client
    const filesystemData: any = await service.browseClientFilesystem(clientId, '');

    if (!filesystemData) {
      res.status(500).json({ error: 'Failed to get filesystem data from client' });
      return;
    }

    // Parse the response and convert to our format
    const roots: any[] = [];

    if (filesystemData.dirs && Array.isArray(filesystemData.dirs)) {
      filesystemData.dirs.forEach((dir: any) => {
        roots.push({
          name: dir.name || dir.path || dir,
          path: dir.path || dir.name || dir,
          type: 'directory',
          hasChildren: true,
          source: 'live_client'
        });
      });
    } else if (Array.isArray(filesystemData)) {
      // Sometimes the response is directly an array
      filesystemData.forEach((item: any) => {
        roots.push({
          name: item.name || item.path || item,
          path: item.path || item.name || item,
          type: item.type === 'dir' || item.dir ? 'directory' : 'file',
          hasChildren: item.type === 'dir' || item.dir,
          source: 'live_client'
        });
      });
    }

    logger.info(`Returning ${roots.length} directories from live client scan`);

    res.json({
      roots,
      source: 'live_client_scan'
    });
  } catch (error: any) {
    logger.error('Failed to browse client filesystem:', error);
    res.status(500).json({
      error: 'Failed to browse client filesystem',
      message: error.message
    });
  }
}

/**
 * Browse subdirectories from client's live filesystem
 */
export async function browseClientDirectory(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const { path } = req.query;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId || !path) {
      res.status(400).json({ error: 'clientId and path are required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    logger.info(`Browsing client ${clientId} directory: ${path}`);

    // Request subdirectory listing from client
    const filesystemData: any = await service.browseClientFilesystem(clientId, path as string);

    const directories: any[] = [];

    if (filesystemData.dirs && Array.isArray(filesystemData.dirs)) {
      filesystemData.dirs.forEach((dir: any) => {
        directories.push({
          name: dir.name || dir.path || dir,
          path: dir.path || `${path}/${dir.name || dir}`,
          type: 'directory',
          hasChildren: true
        });
      });
    } else if (Array.isArray(filesystemData)) {
      filesystemData.filter((item: any) => item.type === 'dir' || item.dir).forEach((dir: any) => {
        directories.push({
          name: dir.name || dir.path || dir,
          path: dir.path || `${path}/${dir.name || dir}`,
          type: 'directory',
          hasChildren: true
        });
      });
    }

    res.json({ directories });
  } catch (error: any) {
    logger.error('Failed to browse client directory:', error);
    res.status(500).json({
      error: 'Failed to browse client directory',
      message: error.message
    });
  }
}

/**
 * Get volumes from client's existing image backups
 */
export async function getClientVolumes(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId) {
      res.status(400).json({ error: 'clientId is required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Get client's existing image backups
    const backups = await service.getBackups(clientId);

    // Extract volumes from image backups
    const volumes = new Set<string>();

    if (backups?.image && Array.isArray(backups.image)) {
      for (const backup of backups.image) {
        // Extract volume letter or device from backup
        if (backup.letter) {
          volumes.add(backup.letter);
        }
        if (backup.image_letter) {
          volumes.add(backup.image_letter);
        }
      }
    }

    // Helper to get effective value based on 'use' flag
    const getEffectiveValue = (setting: any) => {
      if (!setting) return '';
      const use = setting.use;
      if (use === 4) return setting.value_client || ''; // Client override
      if (use === 2) return setting.value || ''; // Server override for this client
      return setting.value_group || ''; // Server/group default
    };

    // Get client settings to see configured volumes
    const settings = await service.getClientSettings(clientId);
    if (settings && Array.isArray(settings) && settings.length > 0) {
      const clientSettings = settings[0];

      // Parse image_letters if available
      if (clientSettings.image_letters) {
        const letters = getEffectiveValue(clientSettings.image_letters);
        if (letters) {
          String(letters).split(';').forEach(letter => {
            if (letter.trim()) {
              volumes.add(letter.trim());
            }
          });
        }
      }
    }

    logger.info(`Returning ${volumes.size} configured volumes for client ${clientId}`);

    res.json({
      volumes: Array.from(volumes),
      source: 'configured_settings'
    });
  } catch (error: any) {
    logger.error('Failed to get client volumes:', error);
    res.status(500).json({
      error: 'Failed to get client volumes',
      message: error.message
    });
  }
}

/**
 * Get client status to determine OS and available information
 */
export async function getClientInfo(req: Request, res: Response) {
  try {
    const { clientId } = req.params;
    const serverId = req.query.serverId as string | undefined;

    if (!clientId) {
      res.status(400).json({ error: 'clientId is required' });
      return;
    }

    const service = await getService(serverId);

    if (!service) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    // Get client status
    const status = await service.getStatus();
    const clients = status as any;

    let clientInfo: any = null;
    if (Array.isArray(clients)) {
      clientInfo = clients.find((c: any) => String(c.id) === String(clientId));
    }

    if (!clientInfo) {
      res.status(404).json({ error: 'Client not found' });
      return;
    }

    res.json({
      id: clientInfo.id,
      name: clientInfo.name,
      online: clientInfo.online || false,
      os_family: clientInfo.os_family || 'unknown',
      os_version: clientInfo.os_version || 'unknown',
      client_version: clientInfo.client_version || 'unknown'
    });
  } catch (error: any) {
    logger.error('Failed to get client info:', error);
    res.status(500).json({
      error: 'Failed to get client info',
      message: error.message
    });
  }
}
