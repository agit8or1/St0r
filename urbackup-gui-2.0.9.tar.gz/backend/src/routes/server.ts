import { Router } from 'express';
import {
  getServers,
  getServer,
  createServer,
  updateServer,
  deleteServer,
  testConnection,
} from '../controllers/server.js';
import { authenticate, requireAdmin } from '../middleware/auth.js';

const router = Router();

// All server routes require authentication
router.use(authenticate);

router.get('/', getServers);
router.get('/:id', getServer);
router.post('/', requireAdmin, createServer);
router.put('/:id', requireAdmin, updateServer);
router.delete('/:id', requireAdmin, deleteServer);
router.post('/test-connection', testConnection);

export default router;
