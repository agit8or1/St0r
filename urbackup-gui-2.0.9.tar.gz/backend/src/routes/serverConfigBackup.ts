import { Router } from 'express';
import {
  createBackup,
  listBackups,
  restoreBackup,
  deleteBackup,
  getBackupDetails
} from '../controllers/serverConfigBackup.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Create new backup
router.post('/create', createBackup);

// List all backups
router.get('/list', listBackups);

// Get backup details
router.get('/:backupId', getBackupDetails);

// Restore from backup
router.post('/:backupId/restore', restoreBackup);

// Delete backup
router.delete('/:backupId', deleteBackup);

export default router;
