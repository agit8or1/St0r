import { Router } from 'express';
import {
  getWindowsInstaller,
  getLinuxInstaller,
  getServerInfo,
} from '../controllers/clientInstaller.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All client installer routes require authentication
router.use(authenticate);

router.get('/windows', getWindowsInstaller);
router.get('/linux', getLinuxInstaller);
router.get('/server-info', getServerInfo);

export default router;
