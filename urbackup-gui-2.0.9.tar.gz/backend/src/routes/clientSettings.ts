import { Router } from 'express';
import { getClientSettings, updateClientSettings } from '../controllers/clientSettings.js';
import { authenticate } from '../middleware/auth.js';

const router = Router();

// All routes require authentication
router.use(authenticate);

// Get client settings
router.get('/:clientId', getClientSettings);

// Update client settings
router.put('/:clientId', updateClientSettings);

export default router;
