import { Response } from 'express';
import { AuthRequest } from '../middleware/auth.js';
import { SystemMonitor } from '../services/systemMonitor.js';
import { getServerById } from '../models/server.js';
import { logger } from '../utils/logger.js';

const monitor = new SystemMonitor();

/**
 * Get system metrics for the St0r server
 */
export async function getSystemMetrics(req: AuthRequest, res: Response): Promise<void> {
  try {
    const metrics = await monitor.getMetrics();
    res.json(metrics);
  } catch (error) {
    logger.error('Failed to get system metrics:', error);
    res.status(500).json({ error: 'Failed to get system metrics' });
  }
}

/**
 * Test latency to a specific UrBackup server
 */
export async function testServerLatency(req: AuthRequest, res: Response): Promise<void> {
  try {
    const { serverId } = req.params;

    if (!serverId) {
      res.status(400).json({ error: 'Server ID is required' });
      return;
    }

    const server = await getServerById(parseInt(serverId));

    if (!server) {
      res.status(404).json({ error: 'Server not found' });
      return;
    }

    const latency = await monitor.testLatency(server.host, server.port);

    res.json({
      serverId: server.id,
      host: server.host,
      port: server.port,
      latency,
      status: latency >= 0 ? 'connected' : 'unreachable'
    });
  } catch (error) {
    logger.error('Failed to test server latency:', error);
    res.status(500).json({ error: 'Failed to test server latency' });
  }
}
