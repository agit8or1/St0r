-- Enhanced schema for RBAC, customers, alerting, and reporting

-- Roles table
CREATE TABLE IF NOT EXISTS roles (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(50) NOT NULL UNIQUE,
    display_name VARCHAR(100) NOT NULL,
    description TEXT,
    is_system BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Permissions table
CREATE TABLE IF NOT EXISTS permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(100) NOT NULL UNIQUE,
    resource VARCHAR(50) NOT NULL,
    action VARCHAR(50) NOT NULL,
    description TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    INDEX idx_resource (resource),
    INDEX idx_action (action)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Role permissions mapping
CREATE TABLE IF NOT EXISTS role_permissions (
    id INT AUTO_INCREMENT PRIMARY KEY,
    role_id INT NOT NULL,
    permission_id INT NOT NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE CASCADE,
    FOREIGN KEY (permission_id) REFERENCES permissions(id) ON DELETE CASCADE,
    UNIQUE KEY unique_role_permission (role_id, permission_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Update app_users table to include role
ALTER TABLE app_users ADD COLUMN role_id INT NULL AFTER is_admin;
ALTER TABLE app_users ADD FOREIGN KEY (role_id) REFERENCES roles(id) ON DELETE SET NULL;

-- Customers table
CREATE TABLE IF NOT EXISTS customers (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    email VARCHAR(255),
    phone VARCHAR(50),
    company VARCHAR(255),
    address TEXT,
    notes TEXT,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    INDEX idx_name (name),
    INDEX idx_email (email),
    INDEX idx_is_active (is_active)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Customer users mapping
CREATE TABLE IF NOT EXISTS customer_users (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    user_id INT NOT NULL,
    is_primary BOOLEAN DEFAULT FALSE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE,
    UNIQUE KEY unique_customer_user (customer_id, user_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Client assignments to customers
CREATE TABLE IF NOT EXISTS customer_clients (
    id INT AUTO_INCREMENT PRIMARY KEY,
    customer_id INT NOT NULL,
    server_id INT NOT NULL,
    client_name VARCHAR(255) NOT NULL,
    client_id VARCHAR(255),
    notes TEXT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (server_id) REFERENCES urbackup_servers(id) ON DELETE CASCADE,
    UNIQUE KEY unique_customer_client (customer_id, server_id, client_name),
    INDEX idx_customer_id (customer_id),
    INDEX idx_server_id (server_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alert rules
CREATE TABLE IF NOT EXISTS alert_rules (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    description TEXT,
    rule_type VARCHAR(50) NOT NULL, -- backup_failed, client_offline, storage_low, etc
    conditions JSON NOT NULL,
    enabled BOOLEAN DEFAULT TRUE,
    notify_email BOOLEAN DEFAULT FALSE,
    notify_pushover BOOLEAN DEFAULT FALSE,
    customer_id INT NULL,
    created_by INT,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES app_users(id) ON DELETE SET NULL,
    INDEX idx_rule_type (rule_type),
    INDEX idx_enabled (enabled),
    INDEX idx_customer_id (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Alert history
CREATE TABLE IF NOT EXISTS alert_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    alert_rule_id INT NOT NULL,
    severity VARCHAR(20) DEFAULT 'warning', -- info, warning, error, critical
    title VARCHAR(255) NOT NULL,
    message TEXT NOT NULL,
    details JSON,
    notified_email BOOLEAN DEFAULT FALSE,
    notified_pushover BOOLEAN DEFAULT FALSE,
    acknowledged BOOLEAN DEFAULT FALSE,
    acknowledged_by INT NULL,
    acknowledged_at TIMESTAMP NULL,
    resolved BOOLEAN DEFAULT FALSE,
    resolved_at TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (alert_rule_id) REFERENCES alert_rules(id) ON DELETE CASCADE,
    FOREIGN KEY (acknowledged_by) REFERENCES app_users(id) ON DELETE SET NULL,
    INDEX idx_severity (severity),
    INDEX idx_acknowledged (acknowledged),
    INDEX idx_resolved (resolved),
    INDEX idx_created_at (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Pushover configuration
CREATE TABLE IF NOT EXISTS pushover_config (
    id INT AUTO_INCREMENT PRIMARY KEY,
    user_id INT NULL,
    customer_id INT NULL,
    app_token VARCHAR(255) NOT NULL,
    user_key VARCHAR(255) NOT NULL,
    device VARCHAR(255),
    priority INT DEFAULT 0,
    is_active BOOLEAN DEFAULT TRUE,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (user_id) REFERENCES app_users(id) ON DELETE CASCADE,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    INDEX idx_user_id (user_id),
    INDEX idx_customer_id (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Reports configuration
CREATE TABLE IF NOT EXISTS reports (
    id INT AUTO_INCREMENT PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    report_type VARCHAR(50) NOT NULL, -- backup_summary, client_status, storage_usage, etc
    parameters JSON,
    schedule VARCHAR(50), -- daily, weekly, monthly, or null for manual
    email_recipients TEXT,
    customer_id INT NULL,
    created_by INT,
    last_run TIMESTAMP NULL,
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (customer_id) REFERENCES customers(id) ON DELETE CASCADE,
    FOREIGN KEY (created_by) REFERENCES app_users(id) ON DELETE SET NULL,
    INDEX idx_report_type (report_type),
    INDEX idx_customer_id (customer_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Report history
CREATE TABLE IF NOT EXISTS report_history (
    id INT AUTO_INCREMENT PRIMARY KEY,
    report_id INT NOT NULL,
    file_path VARCHAR(500),
    file_format VARCHAR(20),
    generated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (report_id) REFERENCES reports(id) ON DELETE CASCADE,
    INDEX idx_report_id (report_id),
    INDEX idx_generated_at (generated_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default roles
INSERT INTO roles (name, display_name, description, is_system) VALUES
('super_admin', 'Super Administrator', 'Full system access with all permissions', TRUE),
('admin', 'Administrator', 'Administrative access to manage customers and settings', TRUE),
('customer_admin', 'Customer Administrator', 'Full access to assigned customer resources', TRUE),
('customer_user', 'Customer User', 'Read-only access to assigned customer resources', TRUE),
('technician', 'Technician', 'Access to manage backups and troubleshoot issues', TRUE);

-- Insert default permissions
INSERT INTO permissions (name, resource, action, description) VALUES
-- User management
('users.view', 'users', 'view', 'View users'),
('users.create', 'users', 'create', 'Create users'),
('users.edit', 'users', 'edit', 'Edit users'),
('users.delete', 'users', 'delete', 'Delete users'),

-- Customer management
('customers.view', 'customers', 'view', 'View customers'),
('customers.create', 'customers', 'create', 'Create customers'),
('customers.edit', 'customers', 'edit', 'Edit customers'),
('customers.delete', 'customers', 'delete', 'Delete customers'),

-- Server management
('servers.view', 'servers', 'view', 'View servers'),
('servers.create', 'servers', 'create', 'Create servers'),
('servers.edit', 'servers', 'edit', 'Edit servers'),
('servers.delete', 'servers', 'delete', 'Delete servers'),

-- Client management
('clients.view', 'clients', 'view', 'View clients'),
('clients.manage', 'clients', 'manage', 'Manage client backups'),

-- Alerts
('alerts.view', 'alerts', 'view', 'View alerts'),
('alerts.manage', 'alerts', 'manage', 'Manage alert rules'),
('alerts.acknowledge', 'alerts', 'acknowledge', 'Acknowledge alerts'),

-- Reports
('reports.view', 'reports', 'view', 'View reports'),
('reports.create', 'reports', 'create', 'Create reports'),
('reports.export', 'reports', 'export', 'Export reports'),

-- Settings
('settings.view', 'settings', 'view', 'View settings'),
('settings.edit', 'settings', 'edit', 'Edit settings');

-- Assign permissions to super_admin role (all permissions)
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'super_admin';

-- Assign permissions to admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'admin'
AND p.name IN (
    'users.view', 'users.create', 'users.edit',
    'customers.view', 'customers.create', 'customers.edit', 'customers.delete',
    'servers.view', 'servers.create', 'servers.edit', 'servers.delete',
    'clients.view', 'clients.manage',
    'alerts.view', 'alerts.manage', 'alerts.acknowledge',
    'reports.view', 'reports.create', 'reports.export',
    'settings.view', 'settings.edit'
);

-- Assign permissions to customer_admin role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'customer_admin'
AND p.name IN (
    'users.view',
    'customers.view',
    'servers.view',
    'clients.view', 'clients.manage',
    'alerts.view', 'alerts.manage', 'alerts.acknowledge',
    'reports.view', 'reports.create', 'reports.export',
    'settings.view'
);

-- Assign permissions to customer_user role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'customer_user'
AND p.name IN (
    'customers.view',
    'servers.view',
    'clients.view',
    'alerts.view',
    'reports.view',
    'settings.view'
);

-- Assign permissions to technician role
INSERT INTO role_permissions (role_id, permission_id)
SELECT r.id, p.id
FROM roles r
CROSS JOIN permissions p
WHERE r.name = 'technician'
AND p.name IN (
    'customers.view',
    'servers.view',
    'clients.view', 'clients.manage',
    'alerts.view', 'alerts.acknowledge',
    'reports.view',
    'settings.view'
);

-- Update existing admin user to have super_admin role
UPDATE app_users
SET role_id = (SELECT id FROM roles WHERE name = 'super_admin')
WHERE username = 'admin';
